#' Microhaplotype Calling from BAM Files
#'
#' This function performs comprehensive microhaplotype calling from BAM files 
#' for targeted sequencing data. It processes both paired-end and single-end 
#' sequencing data to genotype microhaplotype loci using alignment information,
#' quality scores, and variant detection from CIGAR strings and MD tags.
#'
#' @param MH_info Path to the microhaplotype information file (tab-separated).
#'                The file should contain columns: Chr, Start, End, VC (variant
#'                positions), VC_type (variant types), Tar_end, Tar_sat, Tag.
#' @param bam.file BAM file name (without full path).
#' @param wd_link Working directory path where results will be stored.
#' @param lian_qual Read quality threshold for mean Phred quality score.
#' @param base_qual Minimum base quality threshold for variant calling.
#' @param base_qual_include Whether to include base quality filtering ("T" for 
#'                          TRUE, "F" for FALSE).
#' @param other_snp_threshold Frequency threshold for reporting non-target 
#'                            SNPs in the region.
#' @param MH_read_threshold Minimum read count threshold for reporting a 
#'                          microhaplotype.
#' @param MH_ratio_threshold Frequency threshold for microhaplotype calling.
#' @param SNP_ratio_threshold Frequency threshold for SNP calling.
#' @param PE_data Whether the data is paired-end ("T") or single-end ("F").
#'
#' @return The path to the result file containing microhaplotype calling results.
#'         The result file is a tab-separated table with columns:
#'         \itemize{
#'           \item \code{Tag}: Microhaplotype locus identifier
#'           \item \code{Chr}: Chromosome
#'           \item \code{Reads}: Total number of reads covering the locus
#'           \item \code{Target_Microhaplotype_Genotype}: Genotype for target microhaplotype positions
#'           \item \code{Target_SNP_Genotype}: SNP-level genotypes with frequencies
#'           \item \code{Other_SNPs_in_Target_Region}: Non-target SNPs detected in the region with frequencies
#'           \item \code{Haplotypes_in_Target_Region}: All haplotypes observed in the region with read counts
#'           \item \code{Final_Microhaplotype_Genotype}: Final called microhaplotype genotype
#'         }
#'
#' @details
#' The function performs the following main steps:
#' \enumerate{
#'   \item Loads microhaplotype information from the specified file.
#'   \item Sets up working directories for results and intermediate files.
#'   \item For each microhaplotype locus:
#'     \itemize{
#'       \item Extracts genomic region information.
#'       \item Filters BAM file to the target region.
#'       \item Parses CIGAR strings to determine read alignment.
#'       \item Parses MD tags to identify variants.
#'       \item Calls genotypes for target variant positions.
#'       \item Applies quality filters at read and base levels.
#'       \item For paired-end data, merges and compares forward and reverse reads.
#'       \item Summarizes microhaplotype and SNP-level results.
#'       \item Applies frequency thresholds for final calling.
#'     }
#'   \item Writes comprehensive results to output files.
#' }
#'
#' The function handles both paired-end and single-end data with appropriate 
#' processing for each. For paired-end data, it performs additional consistency
#' checks between forward and reverse reads and merges results when concordant.
#'
#' @section File Formats:
#' \strong{Microhaplotype Information File:}
#' Tab-separated file with the following required columns:
#' \itemize{
#'   \item \code{Chr}: Chromosome name (e.g., "chr1")
#'   \item \code{Start}: Start position of the microhaplotype region
#'   \item \code{End}: End position of the microhaplotype region
#'   \item \code{VC}: Variant positions, hyphen-separated (e.g., "100-105-110")
#'   \item \code{VC_type}: Variant types at each position, hyphen-separated (e.g., "A-C-G" for reference alleles)
#'   \item \code{Tar_end}: Primer end position
#'   \item \code{Tar_sat}: Primer start position
#'   \item \code{Tag}: Locus identifier
#' }
#'
#' \strong{Output Result File:}
#' Tab-separated file with comprehensive calling results including read counts,
#' genotypes, frequencies, and quality metrics.
#'
#' @examples
#' \dontrun{
#' # Example for paired-end data
#' result_file <- shinyappMHCalling(
#'   MH_info = "microhaplotypes_info.txt",
#'   bam.file = "sample1.bam",
#'   wd_link = "/path/to/results",
#'   lian_qual = 20,
#'   base_qual = 30,
#'   base_qual_include = "F",
#'   other_snp_threshold = 0.01,
#'   MH_read_threshold = 10,
#'   MH_ratio_threshold = 0.25,
#'   SNP_ratio_threshold = 0.25,
#'   PE_data = "T"
#' )
#'
#' # Read and inspect results
#' results <- read.table(result_file, header = TRUE, sep = "\t")
#' head(results)
#' }
#'
#' @export
#' @keywords genomics variant-calling microhaplotype




shinyappMHCalling<-function(MH_info,bam.file,wd_link,
                            lian_qual,base_qual,base_qual_include,
                            other_snp_threshold,MH_read_threshold,
                            MH_ratio_threshold,
                            SNP_ratio_threshold,
                            PE_data){

  #'   MH_info = "/Users/xuejiaming/Desktop/genetics/HapFinder/Package/序列信息_368_62_1121_PairHMM.txt",
  #    bam.file = "/Users/xuejiaming/Desktop/genetics/HapFinder/Package/processed_bam_2025-12-04-477992566029_sort_calmd.bam",
  #'   wd_link = "/Users/xuejiaming/Desktop/genetics/HapFinder/Package/",
  #'   lian_qual = 20,
  #'   base_qual = 30,
  #'   base_qual_include = "F",
  #'   other_snp_threshold = 0.01,
  #'   MH_read_threshold = 10,
  #'   MH_ratio_threshold = 0.25,
  #'   SNP_ratio_threshold = 0.25,
  #'   PE_data = "T"  

  # ====================================================
  if (missing(MH_info)) stop("MH_info is required!")
  if (missing(bam.file)) stop("bam.file is required!")
  if (missing(wd_link)) stop("wd_link is required!")
  
  # ====================================================
  #report_file <- file.path(wd_link, paste0("MH_Calling_Report_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".txt")

  #message("\n")
  #message("===========================================\n")
  #message("MICROHAPLOTYPE ANALYSIS STARTING\n")
  #message("===========================================\n")
  #message("Parameters used:\n")
  #message("-------------------------------------------\n")
  #message(sprintf("MH Info File: %s\n", basename(MH_info)))
  #message(sprintf("BAM File: %s\n", bam.file))
  #message(sprintf("Output Dir: %s\n", wd_link))
  #message(sprintf("Read Quality: %s\n", lian_qual))
  #message(sprintf("Base Quality Filter: %s\n", ifelse(base_qual_include == "T" || base_qual_include == TRUE, "Enabled", "Disabled")))
  #message(sprintf("Minimum read count for MH reporting: %s\n",  MH_read_threshold))
  #message(sprintf("Minimum Ratio for MH calling: %s\n",  MH_ratio_threshold))
  #message(sprintf("Minimum Ratio for SNP calling: %s\n", SNP_ratio_threshold))
  #message(sprintf("Non-Target SNP Threshold: %s\n",  other_snp_threshold))
  #message(sprintf("Sequencing Type: %s\n", ifelse(PE_data == "T" || PE_data == TRUE, "Paired-End", "Single-End")))
  #message("-------------------------------------------\n")
  ##message("Detailed report saved to:", report_file, "\n")
  #message("===========================================\n\n")
  
  # ====================================================
# Load microhaplotype information file
Ying_MH = as.data.frame(fread(MH_info, sep = "\t", header = T))

# Set up working directories for results and samples
wd_result = paste(wd_link, "/Result/", sep = "")  # Directory for final results
wd_sample = paste(wd_link, "/Sample/", sep = "")  # Directory for sample-specific intermediate files

# Create the directories if they don't exist
dir.create(wd_result)
dir.create(wd_sample)

# Initialize test file counter and output path
pq.test = 1
test.out = paste(wd_link, "/test", pq.test, ".sam", sep = "")

# Initialize the main results data frame with first two columns from Ying_MH
Final_re = Ying_MH[, 1:2]

# Add and initialize result columns with default "Na" (Not Available) values
Final_re$Read_all = "Na"  # Total number of reads for the locus
Final_re$Read_Wrong = "Na"  # Summary of reads failing different filters
Final_re$Result_MH = "Na"  # Microhaplotype results from single reads
Final_re$Result_panda_MH = "Na"  # Merged microhaplotype results from paired reads
Final_re$Result_SNP = "Na"  # SNP-level genotype results
Final_re$Result_original_SNP = "Na"  # Original SNP results including non-target positions
Final_re$Result_original_pan_MH = "Na"  # Original merged microhaplotype results
Final_re$Result_MH_threshold = "Na"  # Microhaplotype results after threshold filtering
Final_re$MH_result = "Na"  # Final microhaplotype calling result
Final_re$Judge_SNP = "Na"  # Judgment of SNP consistency
Final_re$Result_Judge = "Na"  # Final result judgment (TRUE/FALSE)

# Store BAM file name
name = bam.file
print(name)  # Print BAM file name for tracking

#### Process each locus separately for calling
if (PE_data == "T") {
  ## PE: Paired-end data
  #### Process each locus separately for calling
  for (di in 1:nrow(Ying_MH)) try({
    ### Chromosome number
    #di<-1
    # Extract locus information
    chrom = Ying_MH$Chr[di]  # Chromosome
    MH_start = as.numeric(Ying_MH$Start[di])  # Locus start position
    MH_end = as.numeric(Ying_MH$End[di])  # Locus end position
    VC_pos = unlist(str_split(Ying_MH$VC[di], pattern = "-"))  # Physical positions of all variant sites in the microhaplotype
    VC_type = unlist(str_split(Ying_MH$VC_type[di], pattern = "-"))  # Types of all variant sites in the microhaplotype
    Tar_End = as.numeric(Ying_MH$Tar_end[di])  # Primer end physical position
    Tar_Sta = as.numeric(Ying_MH$Tar_sat[di])  # Primer start physical position
    region = paste(paste(chrom, MH_start, sep = ":"), MH_end, sep = "-")  # Genomic region string
    
    # Build BAM file path and index it
    #bam_file <- paste(wd_bam, name, sep = "")
    bam_file<-bam.file
    indexBam(bam_file)
    output_sam <- test.out
    
    # Set parameters for BAM filtering
    threads <- 2  # Number of threads for parallel processing
    mapq <- 30  # Minimum mapping quality
    flags <- scanBamFlag(isUnmappedQuery = FALSE, isSecondaryAlignment = FALSE, isNotPassingQualityControls = FALSE)
    
    # Filter BAM file to extract reads overlapping the target region
    filterBam(bam_file, output_sam, index = bam_file, 
              param = ScanBamParam(which = GRanges(region), flag = flags, mapq = mapq), 
              threads = threads)
    
    # Define ScanBamParam to specify which fields and tags to read
    param <- ScanBamParam(
      what = c("qname", "flag", "rname", "pos", "mapq", "cigar", # "mrnm", 
               "strand", "mpos", "isize", "seq", "qual"),
      tag = "MD"  # Specify to read MD tag for variant information
    )

    
    # Read SAM file
    sam_data1 <- scanBam(output_sam, param = param)
    
    # Extract the read content
    sam_content <- sam_data1[[1]]
    
    # Convert content to data frame
    aln1 <- data.frame(
      V1 = sam_content$qname,    # Read name
      V2 = sam_content$flag,     # SAM flag
      V3 = sam_content$rname,    # Reference name
      V4 = sam_content$pos,      # Mapping position
      V5 = sam_content$mapq,     # Mapping quality
      V6 = sam_content$cigar,    # CIGAR string
      V7 = sam_content$strand,   # Strand
      V8 = sam_content$mpos,     # Mate position
      V9 = sam_content$isize,    # Insert size
      V10 = sam_content$seq,     # Sequence
      V11 = sam_content$qual,    # Quality string
      MD = sam_content$tag$MD    # Extract MD tag (variant information)
    )
    
    ## Clean up the read file to target format
    ## Due to using fill = TRUE when reading, when row content exceeds the first row, it goes to the second row, causing issues.
    ## The following approach removes meaningless rows and replaces MD:Z content to column 13 of the previous row, as calling requires MD:Z
    aln1_na = which(aln1$V13 == "")  # Find rows with empty MD tag
    if (length(aln1_na) > 0) {
      for (fg in 1:length(aln1_na)) {
        # fg = 1
        # Find MD:Z pattern in the row
        MD_OC = as.character(aln1[aln1_na[fg], grep(pattern = "MD:Z", x = aln1[aln1_na[fg], ])])
        if (length(MD_OC) > 0) {
          aln1[aln1_na[fg] - 1, 13] = toupper(MD_OC)  # Copy MD tag to previous row
        }
      }
    }
    if (length(aln1_na) > 0) { aln1 = aln1[-aln1_na, ] }  # Remove empty rows
    
    ## Identify paired read names using table(), paired reads have same name
    ## Set output file format based on strand situation
    read_name = as.data.frame(table(aln1$V1))
    read_name = as.character(read_name$Var1[which(read_name$Freq == 2)])  # Reads with frequency 2 are paired
    
    ####
    # Initialize result table for read pairs
    result_table = data.frame(Tag = read_name)
    
    # Columns for read 1 (reverse strand)
    result_table$Read_1 = "Na"          # Original read calling result
    result_table$MH_1 = "Na"            # Microhaplotype calling result for read 1
    result_table$Qual_1 = "Na"          # Quality scores for read 1
    result_table$PE_1 = "Na"            # Coverage status for read 1
    result_table$MHGQ_mean_1 <- "Na"    # Mean quality for read 1
    result_table$MHGQ_minimum_1 <- "Na" # Minimum quality check for read 1
    result_table$Start_pos_1 = "Na"     # Start position for read 1
    result_table$End_pos_1 = "Na"       # End position for read 1
    
    # Columns for read 2 (forward strand)
    result_table$Read_2 = "Na"          # Original read calling result
    result_table$MH_2 = "Na"            # Microhaplotype calling result for read 2
    result_table$Qual_2 = "Na"          # Quality scores for read 2
    result_table$PE_2 = "Na"            # Coverage status for read 2
    result_table$MHGQ_mean_2 <- "Na"    # Mean quality for read 2
    result_table$MHGQ_minimum_2 <- "Na" # Minimum quality check for read 2
    result_table$Start_pos_2 = "Na"     # Start position for read 2
    result_table$End_pos_2 = "Na"       # End position for read 2
    
    # Result columns
    result_table$Result = "Na"          # Overall result (T/F)
    result_table$Result_Jud = "Na"      # Which filters failed
    result_table$Result_read = "Na"     # Final merged read result
    result_table$Result_Pan_read = "Na" # Combined result from both reads
    
    ## Process each read pair
    ## Process each read in the pair separately
    for (x in 1:nrow(result_table)) try({
      #x<1
      ### Extract read name for current pair
      read_name1 = read_name[x]
      # result_table$Tag[x]
      row_name = which(aln1$V1 == read_name1)  # Find rows for this read name
      
      ## Process each read in the pair
      for (db in 1:length(row_name)) {
        # db = 1; db = 2
        row = row_name[db]
        
        # Check if column 9 contains a minus sign, indicating reverse strand
        # Positive/negative signs represent forward/reverse strands
        # Processing is similar but results are placed in different positions in the file
        if (grepl(aln1$V7[row], pattern = "-")) {
          ## If column 9 contains a minus sign (reverse strand, read 1)
          ## Column 4 is mapping start position, column 10 is sequence, column 11 is per-base quality
          Pos = as.numeric(aln1$V4[row])  # Mapping start position
          seq = aln1$V10[row]             # Read sequence
          qual = aln1$V11[row]            # Quality string
          
          # Calculate mean quality for the read
          MHQual <- unlist(lapply(unlist(str_split(qual, pattern = "")), function(x) {
            # x <- "1"
            ascii_values <- charToAscii(x)  # Convert quality character to Phred score
            ascii_values
          }))
          MHQual1 <- mean(MHQual)  # Mean quality
          result_table$MHGQ_mean_1[x] <- MHQual1
          
          ### Parse CIGAR string (column 6)
          ### CIGAR contains alignment information, mainly numbers and letters
          cigar = aln1$V6[row]
          
          ## Try to split numbers and letters, extract only numbers
          cigar_split1 = unlist(str_split(cigar, pattern = "[A-Z]"))
          cigar_split1 = cigar_split1[which(cigar_split1 != "")]
          
          ## Try to split numbers and letters, extract only letters
          cigar_split2 = unlist(str_split(cigar, pattern = "[0-9]{1,}"))
          cigar_split2 = cigar_split2[which(cigar_split2 != "")]
          
          ### Create matrix of numbers and letters
          cigar_matrix = data.frame(cigar1 = cigar_split1, cigar2 = cigar_split2)
          cigar_matrix$Start = "NA"
          cigar_matrix$End = "NA"
          
          #### Determine start and end positions for each CIGAR operation
          #### CIGAR operations: M, I, S, D (see https://www.jianshu.com/p/12c81825c1f4)
          #### If not S or I, alignment position is not affected, but I or S require different handling
          pos1 = Pos - 1  # Initialize position counter
          for (dh in 1:nrow(cigar_matrix)) {
            # dh = 1; dh = 2; dh = 3
            ci2 = cigar_matrix$cigar2[dh]  # CIGAR operation
            
            #### S: Soft clip, skips part of the read, doesn't change read length
            if (ci2 != "S") {
              if (ci2 != "I") {
                #### When I or S not present, physical position end adds the number of bases
                cigar_matrix$Start[dh] = pos1 + 1
                pos1 = pos1 + as.numeric(cigar_matrix$cigar1[dh])
                cigar_matrix$End[dh] = pos1
              } else {
                #### I: Insertion (contains potential insertion variant)
                #### When I appears, physical position start and end remain the same
                cigar_matrix$Start[dh] = pos1
                cigar_matrix$End[dh] = pos1
              }
            } else {
              #### When S appears, physical position start and end also remain the same
              cigar_matrix$Start[dh] = pos1
              cigar_matrix$End[dh] = pos1
            }
          }
          
          ## Check if read is long enough
          #### If CIGAR starts with S, start position is from the second operation
          #### If CIGAR ends with S, end position is from the previous operation
          if (cigar_matrix$cigar2[1] == "S") {
            lian_start = cigar_matrix$Start[2]
          } else {
            lian_start = cigar_matrix$Start[1]
          }
          if (cigar_matrix$cigar2[nrow(cigar_matrix)] == "S") {
            lian_end = cigar_matrix$End[nrow(cigar_matrix) - 1]
          } else {
            lian_end = cigar_matrix$End[nrow(cigar_matrix)]
          }
          
          ## Convert to numeric
          lian_start = as.numeric(lian_start)
          lian_end = as.numeric(lian_end)
          result_table$Start_pos_1[x] = lian_start
          result_table$End_pos_1[x] = lian_end
          
          #### Check if read covers the entire target amplification region
          #### If not covered, report which positions are not covered
          if (lian_start > as.numeric(VC_pos[1]) | lian_end < as.numeric(VC_pos[length(VC_pos)])) {
            VC_pos = as.numeric(VC_pos)
            # Find positions covered by the read
            num_site = intersect(which(lian_start <= as.numeric(VC_pos)), which(lian_end >= as.numeric(VC_pos)))
            # Get positions NOT covered
            num_site = setdiff(1:length(VC_pos), num_site)
            result_table$PE_1[x] = paste("UnCover", paste(VC_pos[num_site], collapse = "$"), "Position", sep = "_")
          } else {
            result_table$PE_1[x] = "Cover"
          }
          
          ### Modify read information to get quality and sequence aligned to reference
          qual_cigar = NULL  # Quality information
          seq_cigar = NULL   # Sequence information
          sub_qual = 0       # Position counter in original quality/sequence strings
          
          for (dh in 1:nrow(cigar_matrix)) {
            # dh = 1
            ## Analyze each row of cigar_matrix, ci2 is the operation letter
            ci2 = cigar_matrix$cigar2[dh]
            
            if (ci2 == "S") {
              # Soft clip: skip bases
              sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh])
            }
            if (ci2 == "D") {
              ## D: Deletion
              ## Add "D" markers for each deleted base in quality and sequence strings
              del_qual = paste(rep("D", as.numeric(cigar_matrix$cigar1[dh])), collapse = "")
              qual_cigar = paste(qual_cigar, del_qual, sep = "")
              seq_cigar = paste(seq_cigar, del_qual, sep = "")
            }
            if (ci2 == "M") {
              ## M: Match
              ## Extract corresponding quality and sequence for matched region
              qual_cigar1 = str_sub(qual, sub_qual + 1, sub_qual + as.numeric(cigar_matrix$cigar1[dh]))
              qual_cigar = paste(qual_cigar, qual_cigar1, sep = "")
              seq_cigar1 = str_sub(seq, sub_qual + 1, sub_qual + as.numeric(cigar_matrix$cigar1[dh]))
              seq_cigar = paste(seq_cigar, seq_cigar1, sep = "")
              sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh])
            }
            if (ci2 == "I") {
              ## I: Insertion
              sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh])
            }
          }
          
          ### Parse MD tag for variant information
          #MD = gsub(aln1[row, grep(as.character(aln1[row, ]), pattern = "MD:Z:")], 
          #         pattern = "MD:Z:", replacement = "")
          MD<-aln1[row,"MD"]
          ### The MD tag means: 50 matches, then a C variant, then 37 matches, then deletion of AC, etc.
          ## Split MD result
          MD_sub1 = as.data.frame(str_locate_all(MD, "\\D{1,}"))  # Find non-digit positions (variants)
          MD_sub2 = as.data.frame(str_locate_all(MD, "\\d{1,}"))  # Find digit positions (matches)
          
          ## Combine tables to get order of non-digits and digits
          MD_sub = rbind(MD_sub1, MD_sub2)
          MD_sub = arrange(MD_sub, start)
          
          #### Read genotypes from MD tag
          ## Key point: physical positions and genotypes must correspond one-to-one for calling
          pos1 = Pos - 1  # Reset position counter
          hap = "Result"  # Initialize haplotype string
          
          for (ds in 1:nrow(MD_sub)) {
            # ds = 1; ds = 2; ds = 3; ds = 4; ds = 5
            sub_sta = MD_sub$start[ds]
            sub_end = MD_sub$end[ds]
            sub = str_sub(MD, sub_sta, sub_end)  # Extract segment
            
            if (grepl(sub, pattern = "\\^")) {
              #### Check for ^ symbol indicating deletion
              sub1 = gsub(sub, pattern = "\\^", replacement = "")
              len_sub1 = nchar(sub1)  # Determine deletion length
              pos_indel = paste((pos1 + 1):(pos1 + len_sub1), collapse = "-")  # Determine deletion positions
              sub1 = gsub(sub, pattern = "\\^", replacement = "")
              hap1 = paste(pos_indel, paste("Del-", sub1, sep = ""), sep = ":")  # Output deletion genotype
              hap = paste(hap, hap1, sep = "|")  # Combine with haplotype
              pos1 = pos1 + len_sub1  # Update position
            } else {
              if (grepl(sub, pattern = "[A-Z]")) {
                ##### If only letters (no ^), it's a substitution
                len_var = length(sub)  # Determine variant length
                
                for (df in 1:len_var) {
                  # df = 1
                  pos1 = pos1 + 1
                  var_geno = str_sub(seq_cigar, (pos1 - Pos + 1), (pos1 - Pos + 1))  # Get variant from aligned sequence
                  hap1 = paste(pos1, var_geno, sep = ":")
                  hap = paste(hap, hap1, sep = "|")
                }
              } else {
                ##### If only digits, just add to position counter
                pos1 = pos1 + as.numeric(sub)
              }
            }
          }
          
          ### Add insertions from CIGAR (I operations)
          if (grepl(cigar, pattern = "I")) {
            ## Find positions with I operations
            row_I = which(cigar_matrix$cigar2 == "I")
            for (dg in 1:length(row_I)) {
              # dg = 1; dg = 2
              row_I1 = row_I[dg]
              
              # Calculate insertion start and end in original sequence
              ins_sta_row <- cigar_matrix[1:(row_I1 - 1), ]
              ins_sta <- sum(as.numeric(ins_sta_row$cigar1[which(ins_sta_row$cigar2 != "D" & ins_sta_row$cigar2 != "I")])) + 
                         sum(as.numeric(ins_sta_row$cigar1[which(ins_sta_row$cigar2 == "I")]))
              ins_end <- ins_sta + as.numeric(cigar_matrix$cigar1[row_I1])
              
              # Extract inserted sequence
              geno = str_sub(seq, ins_sta + 1, ins_end)
              
              hap1 = paste("InS-", geno, sep = "")
              pos_cal = cigar_matrix[1:(row_I1 - 1), ]
              pos1 = pos_cal$End[nrow(pos_cal)]  # Position before insertion
              hap1 = paste(pos1, hap1, sep = ":")
              hap = paste(hap, hap1, sep = "|")
            }
          }
          
          ### Call microhaplotype genotypes for target positions
          ## hap contains calling results from CIGAR and MD:Z, but we need to call only our target positions
          haplo = "MH"
          hap_try = unlist(str_split(hap, pattern = "[|]", n = Inf))  # Split hap results
          
          #### Call each variant position in VC_pos (our target positions)
          for (dk in 1:length(VC_pos)) {
            # dk = 1; dk = 2; dk = 3; dk = 5
            #### Check if this read covers the position
            if (grepl(pattern = VC_pos[dk], result_table$PE_1[x])) {
              ### If not covered, mark as R:D (Reference, Deletion or missing)
              geno2 = paste(VC_pos[dk], "R", "D", sep = ":")
              haplo = paste(haplo, geno2, sep = "|")
            } else {
              ### If covered, check if position is in hap results
              if (grepl(pattern = VC_pos[dk], x = hap)) {
                ##### If in hap results, extract directly
                geno_all = hap_try[grep(hap_try, pattern = VC_pos[dk])]
                
                ##### Sometimes multiple calls for same position
                if (length(geno_all) > 1) {
                  # When multiple calls exist
                  geno2_try = "geno"
                  for (gen in 1:length(geno_all)) {
                    # gen = 1
                    geno2 = geno_all[gen]
                    
                    #### If "InS" or "Del" exists, don't modify geno2
                    if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                      geno2 = geno2
                    } else {
                      #### If not "InS" or "Del", extract quality at this position
                      site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                      qual1 = str_sub(qual_cigar, site_pos, site_pos)
                      
                
                      ### Combine genotype and base quality
                      geno2 = paste(geno2, qual1, sep = ":")
                    }
                    geno2_try = paste(geno2_try, geno2, sep = "|")
                  }
                  
                  ### Process geno2_try results
                  geno2_try = unlist(str_split(geno2_try, pattern = "\\|"))[-1]
                  geno2_try = str_split_fixed(geno2_try, pattern = ":", n = Inf)
                  
                  ### Output geno2
                  geno2 = paste(VC_pos[dk], 
                               paste(as.character(geno2_try[, 2]), collapse = "-"), 
                               paste(as.character(geno2_try[, 3]), collapse = ""), 
                               sep = ":")
                } else {
                  # When single call exists
                  geno2 = paste(hap_try[grep(hap_try, pattern = VC_pos[dk])], collapse = ";")
                  
                  if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                    geno2 = geno2
                  } else {
                    site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                    qual1 = str_sub(qual_cigar, site_pos, site_pos)
                    # qual1 = gsub(qual1, pattern = "F", replacement = "A")
                    # qual1 = gsub(qual1, pattern = ":", replacement = "B")
                    # qual1 = gsub(qual1, pattern = ",", replacement = "C")
                    geno2 = paste(geno2, qual1, sep = ":")
                  }
                }
                
                #### Combine "MH" and result genotype
                haplo = paste(haplo, geno2, sep = "|")
              } else {
                ##### If not in hap results, it's reference type from VC_type
                geno2 = paste(VC_pos[dk], VC_type[dk], sep = ":")
                
                #### Also check for InS or Del (similar to above)
                if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                  geno2 = geno2
                } else {
                  site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                  qual1 = str_sub(qual_cigar, site_pos, site_pos)
                  # qual1 = gsub(qual1, pattern = "F", replacement = "A")
                  # qual1 = gsub(qual1, pattern = ":", replacement = "B")
                  # qual1 = gsub(qual1, pattern = ",", replacement = "C")
                  geno2 = paste(geno2, qual1, sep = ":")
                }
                
                haplo = paste(haplo, geno2, sep = "|")
              }
            }
          }
          
          #### Incorporate base quality to determine genotype
          ## Actually we could skip this for simplicity, but we keep the code
          re1 = unlist(str_split(haplo, pattern = "[|]"))[-1]  # Split results, get genotype and quality for each position

          ### Loop through each position
          re = lapply(1:length(re1), function(g) {
            # g = 1; g = 2; g = 3
            
            if (grepl("Del", x = re1[g])) {
              ### If Del exists, quality is unknown, marked as D
              qual_re = "D"
              qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
              c(paste(qual_re_le, collapse = ":"), qual_re)
            } else {
              ### If no Del, quality is the annotated quality
              qual_re = unlist(str_split(re1[g], pattern = "[:]"))[3]
              
              ### Check if quality contains C
              ### If contains C, genotype result can be considered N (genotype inaccurate)
              if (grepl(qual_re, pattern = "C")) {
                qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
                c(paste(qual_re_le, collapse = ":"), qual_re)
              } else {
                ### If no C, don't change genotype
                qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
                c(paste(qual_re_le, collapse = ":"), qual_re)
              }
            }
          })
          
          ### Read quality-determined genotype results from previous step
          re2 = unlist(re)
          result_table$Qual_1[x] = paste(re2[seq(from = 2, to = length(re2), by = 2)], collapse = "-")  # Quality results
          result_table$MH_1[x] = paste(re2[seq(from = 1, to = length(re2), by = 2)], collapse = "|")    # Calling results for our positions, ignoring quality
          result_table$Read_1[x] = hap  # Real read calling result
          
          ###### Re-process with quality consideration for final calling
          re = lapply(1:length(re1), function(g) {
            # g = 1; g = 2; g = 3
            #### Check for Del (handled differently in splitting)
            if (grepl("Del", x = re1[g])) {
              qual_re = "D"
              qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
              c(paste(qual_re_le, collapse = ":"), qual_re)
            } else {
              #### No Del, extract directly
              qual_re = unlist(str_split(re1[g], pattern = "[:]"))[3]
              qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
              c(paste(qual_re_le, collapse = ":"), qual_re)
            }
          })
          
          re2 = unlist(re)
          qual.re <- re2[seq(from = 2, to = length(re2), by = 2)]
          qual.len <- length(which(qual.re == ""))
          if (qual.len > 0) { qual.re[which(qual.re == "")] = ":" }
          result_table$Qual_1[x] = paste(qual.re, collapse = "-")  # Quality as scores would be better
          
          #### Add read quality control
          MHGQ_re <- lapply(qual.re, function(x) {
            charToAscii(x)  # Convert quality character to Phred score
          })
          MHGQ <- unlist(MHGQ_re)
          
          # If read doesn't cover all positions, remove uncovered sites from quality check
          if (result_table$PE_1[x] != "Cover") { MHGQ <- MHGQ[-num_site] }
          
          MHGQ_mean <- mean(MHGQ)
          jude1 <- all(MHGQ >= base_qual)  # Check if all positions meet base quality threshold
          result_table$MHGQ_minimum_1[x] <- jude1
        } else {
          # Check if column 9 contains a minus sign
          # Positive/negative signs represent forward/reverse strands
          # Processing is similar but results are placed in different positions
          ### Therefore the following is similar to above but for forward strand (read 2)
          Pos = as.numeric(aln1$V4[row])
          seq = aln1$V10[row]
          qual = aln1$V11[row]
          
          MHQual <- unlist(lapply(unlist(str_split(qual, pattern = "")), function(x) {
            # x <- "1"
            ascii_values <- charToAscii(x)
            ascii_values
            # ACII$ASCII[which(ACII$CHR == x)]
          }))
          MHQual1 <- mean(MHQual)
          result_table$MHGQ_mean_2[x] <- MHQual1
          
          ### Parse CIGAR
          cigar = aln1$V6[row]
          
          cigar_split1 = unlist(str_split(cigar, pattern = "[A-Z]"))
          cigar_split1 = cigar_split1[which(cigar_split1 != "")]
          cigar_split2 = unlist(str_split(cigar, pattern = "[0-9]{1,}"))
          cigar_split2 = cigar_split2[which(cigar_split2 != "")]
          
          cigar_matrix = data.frame(cigar1 = cigar_split1, cigar2 = cigar_split2)
          cigar_matrix$Start = "NA"
          cigar_matrix$End = "NA"
          
          pos1 = Pos - 1
          for (dh in 1:nrow(cigar_matrix)) {
            # dh = 1; dh = 2; dh = 3
            ci2 = cigar_matrix$cigar2[dh]
            if (ci2 != "S") {
              if (ci2 != "I") {
                cigar_matrix$Start[dh] = pos1 + 1
                pos1 = pos1 + as.numeric(cigar_matrix$cigar1[dh])
                cigar_matrix$End[dh] = pos1
              } else {
                cigar_matrix$Start[dh] = pos1
                cigar_matrix$End[dh] = pos1
              }
            } else {
              cigar_matrix$Start[dh] = pos1
              cigar_matrix$End[dh] = pos1
            }
          }
          
          ## Check if read is long enough
          if (cigar_matrix$cigar2[1] == "S") {
            lian_start = cigar_matrix$Start[2]
          } else {
            lian_start = cigar_matrix$Start[1]
          }
          if (cigar_matrix$cigar2[nrow(cigar_matrix)] == "S") {
            lian_end = cigar_matrix$End[nrow(cigar_matrix) - 1]
          } else {
            lian_end = cigar_matrix$End[nrow(cigar_matrix)]
          }
          
          lian_start = as.numeric(lian_start)
          lian_end = as.numeric(lian_end)
          result_table$Start_pos_2[x] = lian_start
          result_table$End_pos_2[x] = lian_end
          
          if (lian_start > as.numeric(VC_pos[1]) | lian_end < as.numeric(VC_pos[length(VC_pos)])) {
            VC_pos = as.numeric(VC_pos)
            num_site = intersect(which(lian_start <= as.numeric(VC_pos)), which(lian_end >= as.numeric(VC_pos)))
            num_site = setdiff(1:length(VC_pos), num_site)
            result_table$PE_2[x] = paste("UnCover", paste(VC_pos[num_site], collapse = "$"), "Position", sep = "_")
          } else {
            result_table$PE_2[x] = "Cover"
          }
          
          ### Modify read information
          qual_cigar = NULL
          seq_cigar = NULL
          sub_qual = 0
          
          for (dh in 1:nrow(cigar_matrix)) {
            # dh = 1
            ci2 = cigar_matrix$cigar2[dh]
            if (ci2 == "S") { sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh]) }
            if (ci2 == "D") {
              del_qual = paste(rep("D", as.numeric(cigar_matrix$cigar1[dh])), collapse = "")
              qual_cigar = paste(qual_cigar, del_qual, sep = "")
              seq_cigar = paste(seq_cigar, del_qual, sep = "")
            }
            if (ci2 == "M") {
              qual_cigar1 = str_sub(qual, sub_qual + 1, sub_qual + as.numeric(cigar_matrix$cigar1[dh]))
              qual_cigar = paste(qual_cigar, qual_cigar1, sep = "")
              seq_cigar1 = str_sub(seq, sub_qual + 1, sub_qual + as.numeric(cigar_matrix$cigar1[dh]))
              seq_cigar = paste(seq_cigar, seq_cigar1, sep = "")
              sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh])
            }
            if (ci2 == "I") {
              sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh])
            }
          }
          
          ### Parse MD tag
         ## MD = gsub(aln1[row, grep(as.character(aln1[row, ]), pattern = "MD:Z:")], 
          #         pattern = "MD:Z:", replacement = "")
          MD<-aln1[row,"MD"]
          MD_sub1 = as.data.frame(str_locate_all(MD, "\\D{1,}"))
          MD_sub2 = as.data.frame(str_locate_all(MD, "\\d{1,}"))
          MD_sub = rbind(MD_sub1, MD_sub2)
          MD_sub = arrange(MD_sub, start)
          
          #### Read genotypes
          pos1 = Pos - 1
          hap = "Result"
          
          for (ds in 1:nrow(MD_sub)) {
            # ds = 1; ds = 2; ds = 3; ds = 4; ds = 5
            sub_sta = MD_sub$start[ds]
            sub_end = MD_sub$end[ds]
            sub = str_sub(MD, sub_sta, sub_end)
            
            if (grepl(sub, pattern = "\\^")) {
              sub1 = gsub(sub, pattern = "\\^", replacement = "")
              len_sub1 = nchar(sub1)
              pos_indel = paste((pos1 + 1):(pos1 + len_sub1), collapse = "-")
              sub1 = gsub(sub, pattern = "\\^", replacement = "")
              hap1 = paste(pos_indel, paste("Del-", sub1, sep = ""), sep = ":")
              hap = paste(hap, hap1, sep = "|")
              pos1 = pos1 + len_sub1
            } else {
              if (grepl(sub, pattern = "[A-Z]")) {
                len_var = length(sub)
                for (df in 1:len_var) {
                  # df = 1
                  pos1 = pos1 + 1
                  var_geno = str_sub(seq_cigar, (pos1 - Pos + 1), (pos1 - Pos + 1))
                  hap1 = paste(pos1, var_geno, sep = ":")
                  hap = paste(hap, hap1, sep = "|")
                }
              } else {
                pos1 = pos1 + as.numeric(sub)
              }
            }
          }
          
          ### Add insertions
          if (grepl(cigar, pattern = "I")) {
            row_I = which(cigar_matrix$cigar2 == "I")
            for (dg in 1:length(row_I)) {
              row_I1 = row_I[dg]
              ins_sta_row <- cigar_matrix[1:(row_I1 - 1), ]
              ins_sta <- sum(as.numeric(ins_sta_row$cigar1[which(ins_sta_row$cigar2 != "D" & ins_sta_row$cigar2 != "I")])) + 
                         sum(as.numeric(ins_sta_row$cigar1[which(ins_sta_row$cigar2 == "I")]))
              ins_end <- ins_sta + as.numeric(cigar_matrix$cigar1[row_I1])
              geno = str_sub(seq, ins_sta + 1, ins_end)
              hap1 = paste("InS-", geno, sep = "")
              pos_cal = cigar_matrix[1:(row_I1 - 1), ]
              pos1 = pos_cal$End[nrow(pos_cal)]
              hap1 = paste(pos1, hap1, sep = ":")
              hap = paste(hap, hap1, sep = "|")
            }
          }
          
          ### Call microhaplotype
          haplo = "MH"
          hap_try = unlist(str_split(hap, pattern = "[|]", n = Inf))
          
          for (dk in 1:length(VC_pos)) {
            # dk = 1; dk = 2; dk = 3; dk = 5
            if (grepl(pattern = VC_pos[dk], result_table$PE_2[x])) {
              geno2 = paste(VC_pos[dk], "R", "D", sep = ":")
              haplo = paste(haplo, geno2, sep = "|")
            } else {
              if (grepl(pattern = VC_pos[dk], x = hap)) {
                geno_all = hap_try[grep(hap_try, pattern = VC_pos[dk])]
                if (length(geno_all) > 1) {
                  geno2_try = "geno"
                  for (gen in 1:length(geno_all)) {
                    # gen = 1
                    geno2 = geno_all[gen]
                    if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                      geno2 = geno2
                    } else {
                      site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                      qual1 = str_sub(qual_cigar, site_pos, site_pos)
                      # qual1 = gsub(qual1, pattern = "F", replacement = "A")
                      # qual1 = gsub(qual1, pattern = ":", replacement = "B")
                      # qual1 = gsub(qual1, pattern = ",", replacement = "C")
                      geno2 = paste(geno2, qual1, sep = ":")
                    }
                    geno2_try = paste(geno2_try, geno2, sep = "|")
                  }
                  geno2_try = unlist(str_split(geno2_try, pattern = "\\|"))[-1]
                  geno2_try = str_split_fixed(geno2_try, pattern = ":", n = Inf)
                  geno2 = paste(VC_pos[dk], 
                               paste(as.character(geno2_try[, 2]), collapse = "-"), 
                               paste(as.character(geno2_try[, 3]), collapse = ""), 
                               sep = ":")
                } else {
                  geno2 = paste(hap_try[grep(hap_try, pattern = VC_pos[dk])], collapse = ";")
                  if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                    geno2 = geno2
                  } else {
                    site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                    qual1 = str_sub(qual_cigar, site_pos, site_pos)
                    # qual1 = gsub(qual1, pattern = "F", replacement = "A")
                    # qual1 = gsub(qual1, pattern = ":", replacement = "B")
                    # qual1 = gsub(qual1, pattern = ",", replacement = "C")
                    geno2 = paste(geno2, qual1, sep = ":")
                  }
                }
                haplo = paste(haplo, geno2, sep = "|")
              } else {
                geno2 = paste(VC_pos[dk], VC_type[dk], sep = ":")
                if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                  geno2 = geno2
                } else {
                  site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                  qual1 = str_sub(qual_cigar, site_pos, site_pos)
                  geno2 = paste(geno2, qual1, sep = ":")
                }
                haplo = paste(haplo, geno2, sep = "|")
              }
            }
          }

          
          #### Incorporate base quality to determine genotype
          re1 = unlist(str_split(haplo, pattern = "[|]"))[-1]
          re = lapply(1:length(re1), function(g) {
            # g = 1; g = 2; g = 3
            
            if (grepl("Del", x = re1[g])) {
              qual_re = "D"
              qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
              c(paste(qual_re_le, collapse = ":"), qual_re)
            } else {
              qual_re = unlist(str_split(re1[g], pattern = "[:]"))[3]
              
              if (grepl(qual_re, pattern = "C")) {
                qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
                c(paste(qual_re_le, collapse = ":"), qual_re)
              } else {
                qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
                c(paste(qual_re_le, collapse = ":"), qual_re)
              }
            }
          })
          
          re2 = unlist(re)
          result_table$Read_2[x] = hap
          
          qual.re <- re2[seq(from = 2, to = length(re2), by = 2)]
          qual.len <- length(which(qual.re == ""))
          if (qual.len > 0) { qual.re[which(qual.re == "")] = ":" }
          result_table$Qual_2[x] = paste(qual.re, collapse = "-")  # Quality as scores would be better
          
          #### Add read quality control
          MHGQ_re <- lapply(qual.re, function(x) {
            charToAscii(x)
          })
          MHGQ <- unlist(MHGQ_re)
          
          if (result_table$PE_2[x] != "Cover") { MHGQ <- MHGQ[-num_site] }
          jude1 <- all(MHGQ >= base_qual)
          result_table$MHGQ_minimum_2[x] <- jude1
          result_table$MH_2[x] = paste(re2[seq(from = 1, to = length(re2), by = 2)], collapse = "|")
        }
      }
      
      #### Check if forward and reverse reads have inconsistent calls in overlapping regions
      pan_sta <- as.integer(result_table$Start_pos_1[x])
      pan_end <- as.integer(result_table$End_pos_2[x])
      panda1 = result_table$Read_1[x]
      panda2 = result_table$Read_2[x]
      
      if (panda1 != "Na" & panda2 != "Na") {
        # If both reads are not NA, split and compare genotypes at each position
        panda1 = unlist(str_split(panda1, pattern = "\\|"))
        panda2 = unlist(str_split(panda2, pattern = "\\|"))
        panda_re1 = unlist(gsub(x = panda1, pattern = ":.*", replacement = ""))  # Extract positions
        panda_re2 = unlist(gsub(x = panda2, pattern = ":.*", replacement = ""))
        pan_inter <- intersect(panda_re1, panda_re2)  # Intersection of positions
        
        if (length(pan_inter) > 1) {
          pan_pos <- as.integer(pan_inter[2:length(pan_inter)])  # Skip first element "Result"
          pan_pos <- pan_pos[which(pan_pos <= pan_end & pan_pos >= pan_sta)]  # Filter to overlapping region
          
          if (length(pan_pos) > 0) {
            re <- lapply(1:length(pan_pos), function(y) {
              # y <- 1
              pos_re <- pan_pos[y]
              pan2 <- panda2[grep(x = panda2, pattern = pos_re)]  # Find call in read 2
              pan1 <- panda1[grep(x = panda1, pattern = pos_re)]  # Find call in read 1
              if (length(pan1) > 0 & length(pan2) > 0) {
                pan1 == pan2  # Compare calls
              } else {
                "FALSE"
              }
            })
            re <- unique(unlist(re))
          } else {
            re <- "TRUE"
          }
          
          if ("FALSE" %in% re) {
            jud2 <- "F"  # Inconsistent calls
          } else {
            jud2 <- "T"  # Consistent calls
          }
        } else {
          jud2 <- "T"
        }
      } else {
        jud2 <- "F"  # One or both reads missing
      }
      
      # Merge consistent reads
      if (jud2 == "T") {
        pan_re <- paste(union(panda2, panda1), collapse = "|")
      } else {
        pan_re <- "Na"
      }
      result_table$Result_Pan_read[x] <- pan_re
      
      #### Check if some positions are not detected in both reads
      # Extract uncovered positions from coverage status
      pan_uncover1 <- unlist(str_split(string = unlist(str_split(string = result_table$PE_1[x], pattern = "_"))[2], 
                                       pattern = "[$]"))
      pan_uncover2 <- unlist(str_split(string = unlist(str_split(string = result_table$PE_2[x], pattern = "_"))[2], 
                                       pattern = "[$]"))
      
      inter1 <- intersect(pan_uncover1, pan_uncover2)  # Positions uncovered in both reads
      if (length(inter1) > 0) {
        jud3 <- "F"  # Some positions uncovered in both reads
      } else {
        jud3 <- "T"  # No positions uncovered in both reads
      }
      
      #### Check if read quality meets threshold
      pan_qual1 <- result_table$MHGQ_mean_1[x]
      pan_qual2 <- result_table$MHGQ_mean_2[x]
      
      if (pan_qual1 >= lian_qual & pan_qual2 >= lian_qual) {
        jud1 <- "T"
      } else {
        jud1 <- "F"
      }
      
      
      ## Read original read results and quality results, merge reads
      panda1 = result_table$MH_1[x]
      panda2 = result_table$MH_2[x]
      panda_qual1 = unlist(str_split(result_table$Qual_1[x], pattern = "-"))
      panda_qual2 = unlist(str_split(result_table$Qual_2[x], pattern = "-"))
      
      if (panda1 != "Na" & panda2 != "Na") {
        # If both reads are not NA, split and compare
        panda1 = unlist(str_split(panda1, pattern = "\\|"))
        panda2 = unlist(str_split(panda2, pattern = "\\|"))
        Result_MH = "MH"
        
        for (fh in 1:length(VC_pos)) {
          # fh = 1; fh = 2; fh = 8; fh = 3; fh = 5; fh = 4
          panda_geno1 = unlist(str_split(panda1[fh], pattern = ":"))[2]  # Genotype from read 1
          panda_geno2 = unlist(str_split(panda2[fh], pattern = ":"))[2]  # Genotype from read 2
          
          #### Check if forward and reverse reads give same result, output directly if consistent
          if (panda_geno1 == panda_geno2) {
            Result_MH = paste(Result_MH, panda1[fh], sep = "|")
          } else {
            #### If inconsistent, apply resolution rules
            # If read 1 is R (reference/missing), use read 2
            if (panda_geno1 == "R") { Result_MH = paste(Result_MH, panda2[fh], sep = "|") }
            # If read 2 is R, use read 1
            if (panda_geno2 == "R") { Result_MH = paste(Result_MH, panda1[fh], sep = "|") }
            # If read 1 is N (ambiguous) and read 2 is not R, use read 2
            if (panda_geno1 == "N" & panda_geno2 != "R") { Result_MH = paste(Result_MH, panda2[fh], sep = "|") }
            # If read 2 is N and read 1 is not R, use read 1
            if (panda_geno2 == "N" & panda_geno1 != "R") { Result_MH = paste(Result_MH, panda1[fh], sep = "|") }
            # If both are not R or N, mark as ambiguous (X)
            if (panda_geno1 != "R" & panda_geno2 != "R" & panda_geno1 != "N" & panda_geno2 != "N") {
              #print(paste(x, fh, sep = "-"))
              Result_MH = paste(Result_MH, paste(VC_pos[fh], "X", sep = ":"), sep = "|")
            }
          }
        }
        
        Result_MH = gsub(Result_MH, pattern = "MH\\|", replacement = "")
        result_table$Result_read[x] = Result_MH
      }
      
      #### Check if sequencing read contains N bases
      re <- unique(unlist(lapply(row_name, function(x) {
        grepl(pattern = "N", x = aln1$V10[x])
      })))
      if ("TRUE" %in% re) {
        jud4 <- "F"  # Contains N bases
      } else {
        jud4 <- "T"  # No N bases
      }
      
      ### Include target base single-base quality
      if (base_qual_include == "F") {
        jud5 = "T"  # Skip quality check
      } else {
        jud5.1 <- result_table$MHGQ_minimum_1[x]
        jud5.2 <- result_table$MHGQ_minimum_2[x]
        if (jud5.1 == "TRUE" & jud5.2 == "TRUE") {
          jud5 = "T"  # Both reads pass quality
        } else {
          jud5 = "F"  # One or both fail quality
        }
      }
      
      ### Determine if to discard this read pair
      if (jud1 == "T" & jud2 == "T" & jud3 == "T" & jud4 == "T" & jud5 == "T") {
        result_table$Result[x] = "T"  # Keep read pair
      } else {
        result_table$Result[x] = "F"  # Discard read pair
      }
      
      # Record which filters failed
      jud.all <- c(jud1, jud2, jud3, jud4, jud5)
      result_table$Result_Jud[x] = paste(which(jud.all == "F"), collapse = "-")
    })
    
    # jud2: forward/reverse read calls inconsistent; jud3: some target positions not detected;
    # jud1: read quality; jud4: contains N bases; jud5: target base quality meets threshold
    
    # Summarize filter failures for this locus
    read.F <- as.data.frame(table(unlist(str_split(result_table$Result_Jud, pattern = "-"))))
    Final_re$Read_Wrong[di] = paste(paste(read.F$Var1, read.F$Freq, sep = ":"), collapse = "\n")
    
    # Filter to keep only passing read pairs
    result_table <- result_table[which(result_table$Result != "F"), ]
    # }
    
    #### After processing all paired or single reads, proceed with analysis
    
    ### Collate results from forward and reverse reads -- single-read analysis
    aa1 = data.frame(table(c(result_table$MH_1, result_table$MH_2)))
    
    #### Remove "Na" reads if present
    if ("Na" %in% aa1$Var1) {
      aa4 = aa1[-which(aa1$Var1 %in% "Na"), ]
    } else {
      aa4 = aa1
    }
    
    ### Count results, reads_all is total reads - double counting paired reads
    reads_all = sum(as.numeric(aa4$Freq))
    Final_re$Read_all[di] <- reads_all
    
    ## Similarly calculate proportion of each MH haplotype, store in Result_MH
    aa3 = aa1[which(as.numeric(aa1$Freq) >= MH_read_threshold), ]
    aa3 = arrange(aa3, desc(Freq))
    Final_re$Result_MH[di] = paste(paste(aa3$Var1, aa3$Freq, sep = " ** "), collapse = "\n")
    
    #### Extract SNP information, split file to have each column as a SNP genotype
    #### Calculate proportions -- paired-read analysis
    aa1 = data.frame(table(c(result_table$Result_read)))
    
    #### Remove "Na" if present
    if ("Na" %in% aa1$Var1) {
      aa4 = aa1[-which(aa1$Var1 %in% "Na"), ]
    } else {
      aa4 = aa1
    }
    
    aa2 = gsub(aa4$Var1, pattern = "[0-9]{1,}:", replacement = "")  # Remove position prefix
    aa2 = gsub(aa2, pattern = "[0-9]{1,}-", replacement = "")  # Remove range indicators
    
    aa2 = str_split_fixed(aa2, pattern = "\\|", n = Inf)  # Split by | to separate SNPs
    aa2 = as.data.frame(aa2)
    aa2$Freq = aa4$Freq
    
    ### Calculate all possible genotypes and proportions for each SNP position
    
    # calculate proportions based on total reads
    re = lapply(1:(ncol(aa2) - 1), function(b) {
      # b = 1
      SNP = unique(aa2[, b])
      re_SNP = VC_pos[b]
      reads.all1 <- sum(as.numeric(aa2$Freq))
      
      for (kg in 1:length(SNP)) {
        # kg = 1
        count_read = round(sum(as.numeric(aa2$Freq[which(aa2[, b] == SNP[kg])])) / reads.all1, 4)
        re_SNP = paste(re_SNP, paste(SNP[kg], count_read, sep = ":"), sep = ";")
      }
      re_SNP
    })
    
    pat1 <- as.character(paste(unlist(re), collapse = "\n"))
    Final_re$Result_SNP[di] <- pat1  # Write to final output
    
    ## Similarly calculate proportion of each MH haplotype, store in Result_MH
    aa3 = aa1[which(as.numeric(aa1$Freq) >= MH_read_threshold), ]
    aa3 = arrange(aa3, desc(Freq))
    Final_re$Result_panda_MH[di] = paste(paste(aa3$Var1, aa3$Freq, sep = " ** "), collapse = "\n")
    
    #### Re-modified - added possibility of other variant positions besides target - 20250215
    aa1 = data.frame(table(c(result_table$Result_Pan_read)))
    
    # Split variant strings by |
    vt1 <- str_split(aa1$Var1, pattern = "[|]")
    vt1 <- lapply(vt1, function(x) {
      # x <- vt1[[6]]
      out1 <- sort(x[2:length(x)], decreasing = F)
      c("Result", out1)
    })
    
    ## First step: replace all deletions with individual position deletions
    re <- lapply(vt1, function(x) {
      # x <- vt1[[1]]
      snp1 <- x
      len1 <- length(grep("Del", x = snp1))
      
      ## Split deletions and then analyze to avoid SNP and InDel at same position
      if (len1 >= 1) {
        del1 <- snp1[grep("Del", x = snp1)]
        re1 <- unique(unlist(lapply(del1, function(x) {
          # x <- del1[1]
          pos1 <- gsub(replacement = "", x, pattern = "[:].*")  # Extract position
          geno1 <- gsub(replacement = "", x, pattern = ".*[:Del-]")  # Extract deleted bases
          
          if (grepl(pattern = "-", x = pos1)) {
            # If position range (e.g., 100-102)
            a1 <- unlist(str_split(pos1, pattern = "-"))
            a2 <- unlist(str_split(geno1, pattern = ""))
            out <- paste(a1, paste("Del-", a2, sep = ""), sep = ":")  # Create individual deletions
          } else {
            out <- NULL
          }
          out
        })))
        snp1 <- snp1[-grep("Del", x = snp1)]  # Remove original deletion entries
        snp1 <- union(snp1, re1)  # Add split deletions
      }
      snp1
    })
    
    snp1 <- unique(unlist(re))
    snp1 <- snp1[-which(snp1 == "Result")]  # Remove "Result" marker
    
    # Reformat variant strings
    re.aa1 <- lapply(1:length(re), function(x) {
      paste(re[[x]], collapse = "|")
    })
    aa1$Var1 <- unlist(re.aa1)
    
    ## Start processing physical positions
    # Get unique positions from all variants
    pos1 <- sort(as.integer(unique(gsub(replacement = "", x = snp1, pattern = "[:].*"))), decreasing = F)
    
    # Remove target positions (VC_pos)
    if (length(which(pos1 %in% VC_pos)) > 0) {
      pos1 <- pos1[-which(pos1 %in% VC_pos)]
    }
    
    # Calculate frequencies for other SNPs (non-target positions)
    vt_geno <- lapply(pos1, function(x) {
      geno1 <- snp1[grep(pattern = x, x = snp1)]  # Variants at this position
      
      ## Count how many reads cover this position
      geno.len <- length(which(as.integer(result_table$Start_pos_2) <= x & 
                               as.integer(result_table$End_pos_1) >= x))
      
      # Calculate frequency of each variant
      re2 <- lapply(geno1, function(z) {
        # z <- geno1[1]
        geno1.len <- grep(z, aa1$Var1)  # Find reads with this variant
        geno1.len <- sum(aa1$Freq[geno1.len])  # Sum frequencies
        round(geno1.len / geno.len, 4)  # Calculate proportion
      })
      re2 <- unlist(re2)
      
      # Filter by threshold
      re2.snp <- which(re2 > other_snp_threshold)
      if (length(re2.snp) > 0) {
        paste(geno1[re2.snp], re2[re2.snp], sep = ":")
      }
    })
    
    vt_geno <- paste(unlist(vt_geno), collapse = "\n")
    Final_re$Result_original_SNP[di] = vt_geno
    
    # Filter full haplotypes by read count
    aa3 = aa1[which(as.numeric(aa1$Freq) >= MH_read_threshold), ]
    aa3 = arrange(aa3, desc(Freq))
    Final_re$Result_original_pan_MH[di] = paste(paste(aa3$Var1, aa3$Freq, sep = " ** "), collapse = "\n")
    
    ######## Write results
    file_name = Ying_MH$Tag[di]
    write.table(result_table, paste(wd_sample, file_name, "_all_Result_PairHMM.txt", sep = ""), 
                sep = "\t", row.names = FALSE)
    #message(paste0("Finished: ",file_name ,"\n"))
    #### Further calling with thresholds
    ig <- di
    if (nchar(Final_re$Result_panda_MH[ig]) == 0 | Final_re$Result_panda_MH[ig] == "Na") {
      # No reads or low reads
      Final_re$Result_MH_threshold[ig] = "Low Reads"
      Final_re$MH_result[ig] = "Low Reads"
      Final_re$Judge_SNP[ig] = "Low Reads"
    } else {
      # Process microhaplotype results
      MH1 = unlist(str_split(Final_re$Result_panda_MH[ig], pattern = "\n"))
      MH1 = as.data.frame(str_split_fixed(MH1, pattern = "[**]", n = Inf))
      
      # Calculate proportions
      re = lapply(1:nrow(MH1), function(x) {
        as.integer(MH1$V3[x]) / sum(as.integer(MH1$V3))
      })
      MH1$Account = unlist(re)
      
      ### Modified proportion method - now proportion of total
      ### [This should also be output to indicate number of results]
      MH2 = MH1[which(MH1$Account >= MH_ratio_threshold), ]
      Final_re$Result_MH_threshold[ig] = paste(MH2$V1, collapse = "\n")
      
      ### Analyze SNP results
      SNP_geno1 = unlist(str_split(Final_re$Result_SNP[ig], pattern = "\n"))
      
      re = lapply(1:length(SNP_geno1), function(x) {
        # x = 1, x = 3
        ### Modified here
        snp1 = unlist(str_split(SNP_geno1[x], pattern = ";"))[-1]  # Remove position
        
        if (length(grep(pattern = "R", snp1)) > 0 & length(snp1) == 1) {
          # Only R (reference/missing)
          "R"
        } else {
          # Remove R if present
          snp1.R <- grep(pattern = "R", snp1)
          if (length(snp1.R) > 0) {
            snp1 = snp1[-grep(pattern = "R", snp1)]
          }
          
          snp2 = as.data.frame(str_split_fixed(snp1, pattern = ":", n = Inf))
          snp2 = arrange(snp2, desc(V2))  # Sort by frequency (V2 is frequency)
          
          # Calculate proportions
          re1 = lapply(1:nrow(snp2), function(g) {
            as.numeric(snp2$V2[g]) / sum(as.numeric(snp2$V2))
          })
          snp2$Account = unlist(re1)
          
          ### SNP-Call modification here
          snp3 = snp2[which(snp2$Account >= SNP_ratio_threshold), ]
          
          if (nrow(snp3) > 2) {
            # If more than 2 alleles pass threshold, take top 2
            sort(snp3$V1[1:2])
          } else {
            sort(snp3$V1)
          }
        }
      })
      
      num_re <- length(unlist(re))  # Total number of SNP calls
      
      if (num_re == length(SNP_geno1)) {
        # All SNPs have calls
        for (eg in 1:nrow(MH2)) {
          # eg = 1
          SNP_MH = gsub(as.character(MH2$V1[eg]), pattern = "[0-9]{1,}:", replacement = "")
          SNP_MH = gsub(SNP_MH, pattern = "[0-9]{1,}-", replacement = "")
          SNP_MH = as.data.frame(str_split_fixed(SNP_MH, pattern = "\\|", n = Inf))
          
          # Get unique alleles for each SNP position from microhaplotype
          re1 = lapply(1:ncol(SNP_MH), function(x) {
            # x = 1
            gsub(sort(unique(SNP_MH[, x])), pattern = " ", replacement = "")
          })
          
          Judge = NULL
          for (ih in 1:length(SNP_geno1)) {
            # ih = 1; ih = 2
            geno1 = re[[ih]]  # SNP calls from data
            geno2 = re1[[ih]]  # SNP calls from microhaplotype
            
            jud1 = "NULL"
            if ("R" %in% geno2) {
              if (length(geno2) == 2) {
                geno2 = geno2[-which(geno2 %in% "R")]  # Remove R if there's another allele
              } else {
                # Only R, use SNP calls from data
                geno2 = geno1
                vc1 = unlist(str_split(SNP_geno1[ih], pattern = ";"))[1]  # Position
                jud1 = paste("Uncover", vc1, "-", paste(geno2, collapse = ";"), sep = "")
              }
            }
            
            if (identical(geno1, geno2)) {
              if (jud1 == "NULL") {
                Judge = paste(Judge, "T", sep = "|")  # Match
              } else {
                Judge = paste(Judge, jud1, sep = "|")  # Uncovered position
              }
            } else {
              Judge = paste(Judge, "F", sep = "|")  # Mismatch
            }
          }
          
          gre_num = grep(Judge, pattern = "F")
          if (length(gre_num) == 0) {
            break  # Found consistent microhaplotype
          }
        }
        
        Final_re$Judge_SNP[ig] = Judge
        Final_re$MH_result[ig] = MH2$V1[eg]
      } else {
        ## Further judgment needed
        num_row = nrow(MH2)
        if (num_row != 1) {
          # Try pairs of microhaplotypes
          for (ij in 1:(num_row - 1)) {
            # ij = 1
            for (ik in (ij + 1):num_row) {
              # ik = 2
              SNP_MH = gsub(as.character(MH2$V1[c(ij, ik)]), pattern = "[0-9]{1,}:", replacement = "")
              SNP_MH = gsub(SNP_MH, pattern = "[0-9]{1,}-", replacement = "")
              
              SNP_MH = as.data.frame(str_split_fixed(SNP_MH, pattern = "\\|", n = Inf))
              re1 = lapply(1:ncol(SNP_MH), function(x) {
                # x = 1
                gsub(sort(unique(SNP_MH[, x])), pattern = " ", replacement = "")
              })
              
              Judge = NULL
              for (ih in 1:length(SNP_geno1)) {
                # ih = 1; ih = 10
                geno1 = re[[ih]]
                geno2 = re1[[ih]]
                jud1 = "NULL"
                
                if ("R" %in% geno2) {
                  if (length(geno2) == 2) {
                    geno2 = geno2[-which(geno2 %in% "R")]
                  } else {
                    geno2 = geno1
                    vc1 = unlist(str_split(SNP_geno1[ih], pattern = ";"))[1]
                    jud1 = paste("Uncover", vc1, "-", paste(geno2, collapse = ";"), sep = "")
                  }
                }
                
                if (identical(geno1, geno2)) {
                  if (jud1 == "NULL") {
                    Judge = paste(Judge, "T", sep = "|")
                  } else {
                    Judge = paste(Judge, jud1, sep = "|")
                  }
                } else {
                  Judge = paste(Judge, "F", sep = "|")
                }
              }
              
              gre_num = grep(Judge, pattern = "F")
              if (length(gre_num) == 0) {
                break  # Found consistent pair
              }
            }
            gre_num = grep(Judge, pattern = "F")
            if (length(gre_num) == 0) {
              break
              
            }
          }
          
          Final_re$MH_result[ig] = paste(as.character(MH2$V1[c(ij, ik)]), collapse = "\n")
          Final_re$Judge_SNP[ig] = Judge
        } else {
          # Single microhaplotype but doesn't match all SNPs
          Final_re$MH_result[ig] = paste(as.character(MH2$V1), collapse = "\n")
          SNP_MH = gsub(as.character(MH2$V1), pattern = "[0-9]{1,}:", replacement = "")
          SNP_MH = gsub(SNP_MH, pattern = "[0-9]{1,}-", replacement = "")
          SNP_MH = as.data.frame(str_split_fixed(SNP_MH, pattern = "\\|", n = Inf))
          
          re1 = lapply(1:ncol(SNP_MH), function(x) {
            # x = 1
            gsub(sort(unique(SNP_MH[, x])), pattern = " ", replacement = "")
          })
          
          Judge = NULL
          for (ih in 1:length(SNP_geno1)) {
            # ih = 1; ih = 2
            geno1 = re[[ih]]
            geno2 = re1[[ih]]
            jud1 = "NULL"
            
            if ("R" %in% geno2) {
              if (length(geno2) == 2) {
                geno2 = geno2[-which(geno2 %in% "R")]
              } else {
                geno2 = geno1
                vc1 = unlist(str_split(SNP_geno1[ih], pattern = ";"))[1]
                jud1 = paste("Uncover", vc1, "-", paste(geno2, collapse = ";"), sep = "")
              }
            }
            
            if (identical(geno1, geno2)) {
              if (jud1 == "NULL") {
                Judge = paste(Judge, "T", sep = "|")
              } else {
                Judge = paste(Judge, jud1, sep = "|")
              }
            } else {
              Judge = paste(Judge, "F", sep = "|")
            }
          }
          Final_re$Judge_SNP[ig] = Judge
        }
      }
    }
    
    # Check if final call matches threshold-filtered results
    if (Final_re$MH_result[ig] == Final_re$Result_MH_threshold[ig]) {
      Final_re$Result_Judge[ig] = "TRUE"
    } else {
      Final_re$Result_Judge[ig] = "FALSE"
    }
    
  })
} else {
  # SE: Single-end data
  # (Similar structure as above but for single-end reads)
  for (di in 1:nrow(Ying_MH)) try({
    # Extract locus information for single-end processing
    chrom = Ying_MH$Chr[di]  # Chromosome number
    ## Locus start position
    MH_start = as.numeric(Ying_MH$Start[di])
    ## Locus end position
    MH_end = as.numeric(Ying_MH$End[di])
    ## Physical positions of all variant sites within the microhaplotype
    VC_pos = unlist(str_split(Ying_MH$VC[di], pattern = "-"))
    ## Types of all variant sites within the microhaplotype
    VC_type = unlist(str_split(Ying_MH$VC_type[di], pattern = "-"))
    ## Primer start and end physical positions
    Tar_End = as.numeric(Ying_MH$Tar_end[di])
    Tar_Sta = as.numeric(Ying_MH$Tar_sat[di])
    region = paste(paste(chrom, MH_start, sep = ":"), MH_end, sep = "-")
    
    # Build BAM file path and index it
    #bam_file <- paste(wd_bam, name, sep = "")
    bam_file<-bam.file
    indexBam(bam_file)
    output_sam <- test.out
    region = paste(paste(chrom, MH_start, sep = ":"), MH_end, sep = "-")
    threads <- 2
    mapq <- 30
    flags <- scanBamFlag(isUnmappedQuery = FALSE, isSecondaryAlignment = FALSE, isNotPassingQualityControls = FALSE)
    
    # Use filterBam function to filter BAM file
    filterBam(bam_file, output_sam, index = bam_file, 
              param = ScanBamParam(which = GRanges(region), flag = flags, mapq = mapq), 
              threads = threads)
    
    # Define ScanBamParam parameters, specifying fields and tags to read
    param <- ScanBamParam(
      what = c("qname", "flag", "rname", "pos", "mapq", "cigar", # "mrnm", 
               "strand", "mpos", "isize", "seq", "qual"),
      tag = "MD"  # Specify to read MD tag
    )
    
    # scanBamWhat()  # (Commented out) Function to list available fields
    
    # Read SAM file
    # output_sam <- bam_file  # (Commented out) Alternative: read directly from BAM
    sam_data1 <- scanBam(output_sam, param = param)
    
    # Extract the read content
    sam_content <- sam_data1[[1]]
    
    # Convert content to data frame
    aln1 <- data.frame(
      V1 = sam_content$qname,
      V2 = sam_content$flag,
      V3 = sam_content$rname,
      V4 = sam_content$pos,
      V5 = sam_content$mapq,
      V6 = sam_content$cigar,
      # mrnm = sam_content$mrnm,  # (Commented out) Mate reference name
      V7 = sam_content$strand,
      V8 = sam_content$mpos,
      V9 = sam_content$isize,
      V10 = sam_content$seq,
      V11 = sam_content$qual,
      MD = sam_content$tag$MD  # Extract MD tag
    )
    
    ## Clean up the read file
    ## When reading with fill = TRUE, if a row has more elements than the first row,
    ## they go to a second row, causing issues. This approach removes meaningless rows
    ## and copies MD:Z content to column 13 of the previous row, as calling needs MD:Z
    aln1_na = which(aln1$V13 == "")
    if (length(aln1_na) > 0) {
      for (fg in 1:length(aln1_na)) {
        # fg = 1
        MD_OC = as.character(aln1[aln1_na[fg], grep(pattern = "MD:Z", x = aln1[aln1_na[fg], ])])
        if (length(MD_OC) > 0) {
          aln1[aln1_na[fg] - 1, 13] = toupper(MD_OC)
        }
      }
    }
    if (length(aln1_na) > 0) { aln1 = aln1[-aln1_na, ] }
    
    # Identify single-end reads (frequency = 1)
    read_name = as.data.frame(table(aln1$V1))
    read_name = as.character(read_name$Var1[which(read_name$Freq == 1)])
    
    ####
    # Initialize result table for single-end reads
    result_table = data.frame(Tag = read_name)
    
    # Only need columns for a single read (read_2 naming convention)
    result_table$Read_2 = "Na"
    result_table$MH_2 = "Na"
    result_table$Qual_2 = "Na"
    result_table$PE_2 = "Na"
    result_table$MHGQ_mean_2 <- "Na"
    result_table$MHGQ_minimum_2 <- "Na"
    result_table$Start_pos_2 = "Na"
    result_table$End_pos_2 = "Na"
    result_table$Result = "Na"
    result_table$Result_Jud = "Na"
    result_table$Result_read = "Na"
    result_table$Result_Pan_read = "Na"
    
    ## Process each read
    for (x in 1:nrow(result_table)) try({
      ### Extract read name for this read
      read_name1 = read_name[x]
      row <- which(aln1$V1 == read_name1)
      
      # Check if column 9 contains a minus sign (indicating strand)
      # Positive/negative signs represent forward/reverse strands
      # Processing is the same, just placed in different file positions
      ## If column 9 contains a minus sign
      ## Column 4 is mapping start, column 10 is sequence, column 11 is base quality
      
      Pos = as.numeric(aln1$V4[row])
      seq = aln1$V10[row]
      qual = aln1$V11[row]
      
      # Calculate mean quality for the read
      MHQual <- unlist(lapply(unlist(str_split(qual, pattern = "")), function(x) {
        # x <- "1"
        ascii_values <- charToAscii(x)
        ascii_values
      }))
      MHQual1 <- mean(MHQual)
      result_table$MHGQ_mean_2[x] <- MHQual1
      
      ### Parse CIGAR string
      cigar = aln1$V6[row]
      cigar_split1 = unlist(str_split(cigar, pattern = "[A-Z]"))
      cigar_split1 = cigar_split1[which(cigar_split1 != "")]
      cigar_split2 = unlist(str_split(cigar, pattern = "[0-9]{1,}"))
      cigar_split2 = cigar_split2[which(cigar_split2 != "")]
      cigar_matrix = data.frame(cigar1 = cigar_split1, cigar2 = cigar_split2)
      cigar_matrix$Start = "NA"
      cigar_matrix$End = "NA"
      
      pos1 = Pos - 1
      for (dh in 1:nrow(cigar_matrix)) {
        # dh = 1; dh = 2; dh = 3
        ci2 = cigar_matrix$cigar2[dh]
        if (ci2 != "S") {
          if (ci2 != "I") {
            cigar_matrix$Start[dh] = pos1 + 1
            pos1 = pos1 + as.numeric(cigar_matrix$cigar1[dh])
            cigar_matrix$End[dh] = pos1
          } else {
            cigar_matrix$Start[dh] = pos1
            cigar_matrix$End[dh] = pos1
          }
        } else {
          cigar_matrix$Start[dh] = pos1
          cigar_matrix$End[dh] = pos1
        }
      }
      
      ## Check if read is long enough
      if (cigar_matrix$cigar2[1] == "S") {
        lian_start = cigar_matrix$Start[2]
      } else {
        lian_start = cigar_matrix$Start[1]
      }
      if (cigar_matrix$cigar2[nrow(cigar_matrix)] == "S") {
        lian_end = cigar_matrix$End[nrow(cigar_matrix) - 1]
      } else {
        lian_end = cigar_matrix$End[nrow(cigar_matrix)]
      }
      
      lian_start = as.numeric(lian_start)
      lian_end = as.numeric(lian_end)
      result_table$Start_pos_2[x] = lian_start
      result_table$End_pos_2[x] = lian_end
      
      # Check if read covers all target positions
      if (lian_start > as.numeric(VC_pos[1]) | lian_end < as.numeric(VC_pos[length(VC_pos)])) {
        VC_pos = as.numeric(VC_pos)
        num_site = intersect(which(lian_start <= as.numeric(VC_pos)), which(lian_end >= as.numeric(VC_pos)))
        num_site = setdiff(1:length(VC_pos), num_site)
        result_table$PE_2[x] = paste("UnCover", paste(VC_pos[num_site], collapse = "$"), "Position", sep = "_")
      } else {
        result_table$PE_2[x] = "Cover"
      }
      
      ### Modify read information based on CIGAR
      qual_cigar = NULL
      seq_cigar = NULL
      sub_qual = 0
      
      for (dh in 1:nrow(cigar_matrix)) {
        # dh = 1
        ci2 = cigar_matrix$cigar2[dh]
        if (ci2 == "S") { sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh]) }
        if (ci2 == "D") {
          del_qual = paste(rep("D", as.numeric(cigar_matrix$cigar1[dh])), collapse = "")
          qual_cigar = paste(qual_cigar, del_qual, sep = "")
          seq_cigar = paste(seq_cigar, del_qual, sep = "")
        }
        if (ci2 == "M") {
          qual_cigar1 = str_sub(qual, sub_qual + 1, sub_qual + as.numeric(cigar_matrix$cigar1[dh]))
          qual_cigar = paste(qual_cigar, qual_cigar1, sep = "")
          seq_cigar1 = str_sub(seq, sub_qual + 1, sub_qual + as.numeric(cigar_matrix$cigar1[dh]))
          seq_cigar = paste(seq_cigar, seq_cigar1, sep = "")
          sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh])
        }
        if (ci2 == "I") {
          sub_qual = sub_qual + as.numeric(cigar_matrix$cigar1[dh])
        }
      }
      
      ### Parse MD tag for variants
     # MD = gsub(aln1[row, grep(as.character(aln1[row, ]), pattern = "MD:Z:")], 
      #          pattern = "MD:Z:", replacement = "")
      MD<-aln1[row,"MD"]
      MD_sub1 = as.data.frame(str_locate_all(MD, "\\D{1,}"))
      MD_sub2 = as.data.frame(str_locate_all(MD, "\\d{1,}"))
      MD_sub = rbind(MD_sub1, MD_sub2)
      MD_sub = arrange(MD_sub, start)
      
      #### Read genotypes from MD tag
      pos1 = Pos - 1
      hap = "Result"
      
      for (ds in 1:nrow(MD_sub)) {
        sub_sta = MD_sub$start[ds]
        sub_end = MD_sub$end[ds]
        sub = str_sub(MD, sub_sta, sub_end)
        
        if (grepl(sub, pattern = "\\^")) {
          sub1 = gsub(sub, pattern = "\\^", replacement = "")
          len_sub1 = nchar(sub1)
          pos_indel = paste((pos1 + 1):(pos1 + len_sub1), collapse = "-")
          sub1 = gsub(sub, pattern = "\\^", replacement = "")
          hap1 = paste(pos_indel, paste("Del-", sub1, sep = ""), sep = ":")
          hap = paste(hap, hap1, sep = "|")
          pos1 = pos1 + len_sub1
        } else {
          if (grepl(sub, pattern = "[A-Z]")) {
            len_var = length(sub)
            for (df in 1:len_var) {
              # df = 1
              pos1 = pos1 + 1
              var_geno = str_sub(seq_cigar, (pos1 - Pos + 1), (pos1 - Pos + 1))  # Get variant from aligned sequence
              hap1 = paste(pos1, var_geno, sep = ":")
              hap = paste(hap, hap1, sep = "|")
            }
          } else {
            pos1 = pos1 + as.numeric(sub)
          }
        }
      }
      
      ### Add insertions from CIGAR (I operations)
      if (grepl(cigar, pattern = "I")) {
        row_I = which(cigar_matrix$cigar2 == "I")
        for (dg in 1:length(row_I)) {
          # dg = 1; dg = 2
          row_I1 = row_I[dg]
          geno = str_sub(seq, sum(as.numeric(cigar_matrix$cigar1[1:(row_I1 - 1)])) + 1, 
                         sum(as.numeric(cigar_matrix$cigar1[1:row_I1])))
          hap1 = paste("InS-", geno, sep = "")
          pos_cal = cigar_matrix[1:(row_I1 - 1), ]
          pos1 = pos_cal$End[nrow(pos_cal)]  # Position before insertion
          hap1 = paste(pos1, hap1, sep = ":")
          hap = paste(hap, hap1, sep = "|")
        }
      }
      
      ### Call microhaplotype genotypes for target positions
      haplo = "MH"
      hap_try = unlist(str_split(hap, pattern = "[|]", n = Inf))
      
      for (dk in 1:length(VC_pos)) {
        # dk = 1; dk = 2; dk = 3; dk = 5
        if (grepl(pattern = VC_pos[dk], result_table$PE_2[x])) {
          # Position not covered
          geno2 = paste(VC_pos[dk], "R", "?", sep = ":")
          haplo = paste(haplo, geno2, sep = "|")
        } else {
          if (grepl(pattern = VC_pos[dk], x = hap)) {
            # Position has variant call
            geno_all = hap_try[grep(hap_try, pattern = VC_pos[dk])]
            if (length(geno_all) > 1) {
              # Multiple calls for same position
              geno2_try = "geno"
              for (gen in 1:length(geno_all)) {
                # gen = 1
                geno2 = geno_all[gen]
                if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                  geno2 = geno2
                } else {
                  site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                  qual1 = str_sub(qual_cigar, site_pos, site_pos)
                  # Convert quality characters to standardized codes
                  qual1 = gsub(qual1, pattern = "F", replacement = "A")
                  qual1 = gsub(qual1, pattern = ":", replacement = "B")
                  qual1 = gsub(qual1, pattern = ",", replacement = "C")
                  geno2 = paste(geno2, qual1, sep = ":")
                }
                geno2_try = paste(geno2_try, geno2, sep = "|")
              }
              geno2_try = unlist(str_split(geno2_try, pattern = "\\|"))[-1]
              geno2_try = str_split_fixed(geno2_try, pattern = ":", n = Inf)
              geno2 = paste(VC_pos[dk], 
                            paste(as.character(geno2_try[, 2]), collapse = "-"), 
                            paste(as.character(geno2_try[, 3]), collapse = ""), 
                            sep = ":")
            } else {
              # Single call
              geno2 = paste(hap_try[grep(hap_try, pattern = VC_pos[dk])], collapse = ";")
              if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
                geno2 = geno2
              } else {
                site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
                qual1 = str_sub(qual_cigar, site_pos, site_pos)
                # Convert quality characters to standardized codes
                qual1 = gsub(qual1, pattern = "F", replacement = "A")
                qual1 = gsub(qual1, pattern = ":", replacement = "B")
                qual1 = gsub(qual1, pattern = ",", replacement = "C")
                geno2 = paste(geno2, qual1, sep = ":")
              }
            }
            haplo = paste(haplo, geno2, sep = "|")
          } else {
            # Position is reference
            geno2 = paste(VC_pos[dk], VC_type[dk], sep = ":")
            if (grepl("InS", x = geno2) | grepl("Del", x = geno2)) {
              geno2 = geno2
            } else {
              site_pos = as.numeric(VC_pos[dk]) - as.numeric(Pos) + 1
              qual1 = str_sub(qual_cigar, site_pos, site_pos)
              # Convert quality characters to standardized codes
              qual1 = gsub(qual1, pattern = "F", replacement = "A")
              qual1 = gsub(qual1, pattern = ":", replacement = "B")
              qual1 = gsub(qual1, pattern = ",", replacement = "C")
              geno2 = paste(geno2, qual1, sep = ":")
            }
            haplo = paste(haplo, geno2, sep = "|")
          }
        }
      }
      
      
      #### Incorporate base quality to determine genotype
      re1 = unlist(str_split(haplo, pattern = "[|]"))[-1]
      re = lapply(1:length(re1), function(g) {
        # g = 1; g = 2; g = 3
        if (grepl("Del", x = re1[g])) {
          qual_re = "D"
          qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
          c(paste(qual_re_le, collapse = ":"), qual_re)
        } else {
          qual_re = unlist(str_split(re1[g], pattern = "[:]"))[3]
          if (grepl(qual_re, pattern = "C")) {
            # Low quality - mark as ambiguous
            qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
            c(paste(qual_re_le, collapse = ":"), qual_re)
          } else {
            qual_re_le = unlist(str_split(re1[g], pattern = "[:]"))[1:2]
            c(paste(qual_re_le, collapse = ":"), qual_re)
          }
        }
      })
      
      re2 = unlist(re)
      result_table$Read_2[x] = hap
      
      qual.re <- re2[seq(from = 2, to = length(re2), by = 2)]
      qual.len <- length(which(qual.re == ""))
      if (qual.len > 0) { qual.re[which(qual.re == "")] = ":" }
      result_table$Qual_2[x] = paste(qual.re, collapse = "-")  # Quality as scores would be better
      
      #### Add read quality control
      MHGQ_re <- lapply(qual.re, function(x) {
        charToAscii(x)
      })
      MHGQ <- unlist(MHGQ_re)
      
      # If read doesn't cover all positions, remove uncovered sites from quality check
      if (result_table$PE_2[x] != "Cover") { MHGQ <- MHGQ[-num_site] }
      jude1 <- all(MHGQ >= base_qual)
      result_table$MHGQ_minimum_2[x] <- jude1
      result_table$MH_2[x] = paste(re2[seq(from = 1, to = length(re2), by = 2)], collapse = "|")
      
      #### Check if some positions are not detected
      pan_uncover1 <- grepl(result_table$PE_2[x], pattern = "UnCover")
      if (pan_uncover1 == "TRUE") {
        jud3 <- "F"  # Some positions not covered
      } else {
        jud3 <- "T"  # All positions covered
      }
      
      #### Check if read quality meets threshold
      pan_qual1 <- result_table$MHGQ_mean_2[x]
      if (pan_qual1 >= lian_qual) {
        jud1 <- "T"
      } else {
        jud1 <- "F"
      }
      
      #### Check if sequencing read contains N bases
      re <- unique(unlist(lapply(row, function(x) {
        grepl(pattern = "N", x = aln1$V10[x])
      })))
      if ("TRUE" %in% re) {
        jud4 <- "F"  # Contains N bases
      } else {
        jud4 <- "T"  # No N bases
      }
      
      ### Include target base single-base quality
      if (base_qual_include == "F") {
        jud5 = "T"  # Skip quality check
      } else {
        jud5.2 <- result_table$MHGQ_minimum_2[x]
        if (jud5.2 == "TRUE") {
          jud5 = "T"  # Read passes quality
        } else {
          jud5 = "F"  # Read fails quality
        }
      }
      
      ### Determine if to discard this read
      if (jud1 == "T" & jud3 == "T" & jud4 == "T" & jud5 == "T") {
        result_table$Result[x] = "T"  # Keep read
      } else {
        result_table$Result[x] = "F"  # Discard read
      }
      
      # Record which filters failed
      jud.all <- c(jud1, jud3, jud4, jud5)
      result_table$Result_Jud[x] = paste(which(jud.all == "F"), collapse = "-")
      
      ####
      # 1: Whether read quality meets threshold
      # 3: Whether read covers the entire region
      # 4: Whether sequencing read contains N bases
      # 5: Whether target base single-base quality is included
    })
    
    # jud2: forward/reverse read calls inconsistent; jud3: some target positions not detected;
    # jud1: read quality; jud4: contains N bases; jud5: target base quality meets threshold
    
    # Summarize filter failures for this locus
    read.F <- as.data.frame(table(unlist(str_split(result_table$Result_Jud, pattern = "-"))))
    Final_re$Read_Wrong[di] = paste(paste(read.F$Var1, read.F$Freq, sep = ":"), collapse = "\n")
    
    # Filter to keep only passing reads
    result_table <- result_table[which(result_table$Result != "F"), ]
    
    #### After processing all reads, proceed with analysis
    #wd_link1 = paste(wd_sample, list_bam[i], sep = "/")  
    
    ### Collate results from reads -- single-read analysis
    aa1 = data.frame(table(c(result_table$MH_2)))
    
    #### Remove "Na" reads if present
    if ("Na" %in% aa1$Var1) {
      aa4 = aa1[-which(aa1$Var1 %in% "Na"), ]
    } else {
      aa4 = aa1
    }
    
    ### Count results, reads_all is total reads
    reads_all = sum(as.numeric(aa4$Freq))
    Final_re$Read_all[di] <- reads_all
    
    ## Calculate proportion of each MH haplotype, store in Result_MH
    aa3 = aa1[which(as.numeric(aa1$Freq) >= MH_read_threshold), ]
    aa3 = arrange(aa3, desc(Freq))
    Final_re$Result_MH[di] = paste(paste(aa3$Var1, aa3$Freq, sep = " ** "), collapse = "\n")
    
    # For single-end data, result_read is the same as MH_2
    result_table$Result_read <- result_table$MH_2
    
    #### Extract SNP information, split file to have each column as a SNP genotype
    #### Calculate proportions -- single-read analysis
    aa1 = data.frame(table(c(result_table$Result_read)))
    
    #### Remove "Na" if present
    if ("Na" %in% aa1$Var1) {
      aa4 = aa1[-which(aa1$Var1 %in% "Na"), ]
    } else {
      aa4 = aa1
    }
    
    aa2 = gsub(aa4$Var1, pattern = "[0-9]{1,}:", replacement = "")  # Remove position prefix
    aa2 = gsub(aa2, pattern = "[0-9]{1,}-", replacement = "")  # Remove range indicators
    aa2 = str_split_fixed(aa2, pattern = "\\|", n = Inf)  # Split by | to separate SNPs
    aa2 = as.data.frame(aa2)
    aa2$Freq = aa4$Freq
    
    ### Calculate all possible genotypes and proportions for each SNP position
    # calculate proportions based on total reads
    re = lapply(1:(ncol(aa2) - 1), function(b) {
      # b = 1
      SNP = unique(aa2[, b])
      re_SNP = VC_pos[b]
      reads.all1 <- sum(as.numeric(aa2$Freq))
      
      for (kg in 1:length(SNP)) {
        # kg = 1
        count_read = round(sum(as.numeric(aa2$Freq[which(aa2[, b] == SNP[kg])])) / reads.all1, 4)
        re_SNP = paste(re_SNP, paste(SNP[kg], count_read, sep = ":"), sep = ";")
      }
      re_SNP
    })
    
    pat1 <- as.character(paste(unlist(re), collapse = "\n"))
    Final_re$Result_SNP[di] <- pat1  # Write to final output
    
    ## Calculate proportion of each MH haplotype, store in Result_MH
    aa3 = aa1[which(as.numeric(aa1$Freq) >= MH_read_threshold), ]
    aa3 = arrange(aa3, desc(Freq))
    Final_re$Result_panda_MH[di] = paste(paste(aa3$Var1, aa3$Freq, sep = " ** "), collapse = "\n")
    
    # For single-end data, Result_Pan_read is the same as Read_2
    result_table$Result_Pan_read <- result_table$Read_2
    
    #### Re-modified - added possibility of other variant positions besides target - 20250215
    aa1 = data.frame(table(c(result_table$Result_Pan_read)))
    
    # Split variant strings by |
    vt1 <- str_split(aa1$Var1, pattern = "[|]")
    vt1 <- lapply(vt1, function(x) {
      out1 <- sort(x[2:length(x)], decreasing = F)
      c("Result", out1)
    })
    
    ## First step: replace all deletions with individual position deletions
    re <- lapply(vt1, function(x) {
      snp1 <- x
      len1 <- length(grep("Del", x = snp1))
      
      ## Split deletions to avoid SNP and InDel at same position
      if (len1 >= 1) {
        del1 <- snp1[grep("Del", x = snp1)]
        re1 <- unique(unlist(lapply(del1, function(x) {
          # x <- del1[1]
          pos1 <- gsub(replacement = "", x, pattern = "[:].*")  # Extract position
          geno1 <- gsub(replacement = "", x, pattern = ".*[:Del-]")  # Extract deleted bases
          
          if (grepl(pattern = "-", x = pos1)) {
            # If position range (e.g., 100-102)
            a1 <- unlist(str_split(pos1, pattern = "-"))
            a2 <- unlist(str_split(geno1, pattern = ""))
            out <- paste(a1, paste("Del-", a2, sep = ""), sep = ":")  # Create individual deletions
          } else {
            out <- NULL
          }
          out
        })))
        snp1 <- snp1[-grep("Del", x = snp1)]  # Remove original deletion entries
        snp1 <- union(snp1, re1)  # Add split deletions
      }
      snp1
    })
    
    snp1 <- unique(unlist(re))
    snp1 <- snp1[-which(snp1 == "Result")]  # Remove "Result" marker
    
    # Reformat variant strings
    re.aa1 <- lapply(1:length(re), function(x) {
      paste(re[[x]], collapse = "|")
    })
    aa1$Var1 <- unlist(re.aa1)
    
    ## Start processing physical positions
    # Get unique positions from all variants
    pos1 <- sort(as.integer(unique(gsub(replacement = "", x = snp1, pattern = "[:].*"))), decreasing = F)
    
    # Remove target positions (VC_pos)
    if (length(which(pos1 %in% VC_pos)) > 0) {
      pos1 <- pos1[-which(pos1 %in% VC_pos)]
    }
    
    # Calculate frequencies for other SNPs (non-target positions)
    vt_geno <- lapply(pos1, function(x) {
      geno1 <- snp1[grep(pattern = x, x = snp1)]  # Variants at this position
      
      ## Count how many reads cover this position
      geno.len <- length(which(as.integer(result_table$Start_pos_2) <= x & 
                                 as.integer(result_table$End_pos_2) >= x))
      
      # Calculate frequency of each variant
      re2 <- lapply(geno1, function(z) {
        # z <- geno1[1]
        geno1.len <- grep(z, aa1$Var1)  # Find reads with this variant
        geno1.len <- sum(aa1$Freq[geno1.len])  # Sum frequencies
        round(geno1.len / geno.len, 4)  # Calculate proportion
      })
      re2 <- unlist(re2)
      
      # Filter by threshold
      re2.snp <- which(re2 > other_snp_threshold)
      if (length(re2.snp) > 0) {
        paste(geno1[re2.snp], re2[re2.snp], sep = ":")
      }
    })
    
    vt_geno <- paste(unlist(vt_geno), collapse = "\n")
    Final_re$Result_original_SNP[di] = vt_geno
    
    # Filter full haplotypes by read count
    aa3 = aa1[which(as.numeric(aa1$Freq) >= MH_read_threshold), ]
    aa3 = arrange(aa3, desc(Freq))
    Final_re$Result_original_pan_MH[di] = paste(paste(aa3$Var1, aa3$Freq, sep = " ** "), collapse = "\n")
    
    ######## Write results
    file_name = Ying_MH$Tag[di]
    write.table(result_table, paste(wd_sample, file_name, "_all_Result_PairHMM.txt", sep = ""), 
                sep = "\t", row.names = FALSE)
    #message(paste0("Finished: ",file_name,"\n" ))
    #### Further calling with thresholds
    ig <- di
    # ig = 2;
    
    if (nchar(Final_re$Result_panda_MH[ig]) == 0 | Final_re$Result_panda_MH[ig] == "Na") {
      # No reads or low reads
      Final_re$Result_MH_threshold[ig] = "Low Reads"
      Final_re$MH_result[ig] = "Low Reads"
      Final_re$Judge_SNP[ig] = "Low Reads"
    } else {
      # Process microhaplotype results
      MH1 = unlist(str_split(Final_re$Result_panda_MH[ig], pattern = "\n"))
      MH1 = as.data.frame(str_split_fixed(MH1, pattern = "[**]", n = Inf))
      
      # Calculate proportions
      re = lapply(1:nrow(MH1), function(x) {
        as.integer(MH1$V3[x]) / sum(as.integer(MH1$V3))
      })
      MH1$Account = unlist(re)
      
      ### Modified proportion method - now proportion of total
      ### [This should also be output to indicate number of results]
      MH2 = MH1[which(MH1$Account >= MH_ratio_threshold), ]
      Final_re$Result_MH_threshold[ig] = paste(MH2$V1, collapse = "\n")
      
      ### Analyze SNP results
      SNP_geno1 = unlist(str_split(Final_re$Result_SNP[ig], pattern = "\n"))
      
      re = lapply(1:length(SNP_geno1), function(x) {
        # x = 1, x = 3
        ### Modified here
        snp1 = unlist(str_split(SNP_geno1[x], pattern = ";"))[-1]  # Remove position
        
        if (length(grep(pattern = "R", snp1)) > 0 & length(snp1) == 1) {
          # Only R (reference/missing)
          "R"
        } else {
          # Remove R if present
          snp1.R <- grep(pattern = "R", snp1)
          if (length(snp1.R) > 0) {
            snp1 = snp1[-grep(pattern = "R", snp1)]
          }
          
          snp2 = as.data.frame(str_split_fixed(snp1, pattern = ":", n = Inf))
          snp2 = arrange(snp2, desc(V2))  # Sort by frequency (V2 is frequency)
          
          # Calculate proportions
          re1 = lapply(1:nrow(snp2), function(g) {
            as.numeric(snp2$V2[g]) / sum(as.numeric(snp2$V2))
          })
          snp2$Account = unlist(re1)
          
          ### SNP-Call modification here
          snp3 = snp2[which(snp2$Account >= SNP_ratio_threshold), ]
          
          if (nrow(snp3) > 2) {
            # If more than 2 alleles pass threshold, take top 2
            sort(snp3$V1[1:2])
          } else {
            sort(snp3$V1)
          }
        }
      })
      
      num_re <- length(unlist(re))  # Total number of SNP calls
      
      if (num_re == length(SNP_geno1)) {
        # All SNPs have calls
        for (eg in 1:nrow(MH2)) {
          # eg = 1
          SNP_MH = gsub(as.character(MH2$V1[eg]), pattern = "[0-9]{1,}:", replacement = "")
          SNP_MH = gsub(SNP_MH, pattern = "[0-9]{1,}-", replacement = "")
          SNP_MH = as.data.frame(str_split_fixed(SNP_MH, pattern = "\\|", n = Inf))
          
          # Get unique alleles for each SNP position from microhaplotype
          re1 = lapply(1:ncol(SNP_MH), function(x) {
            # x = 1
            gsub(sort(unique(SNP_MH[, x])), pattern = " ", replacement = "")
          })
          
          Judge = NULL
          for (ih in 1:length(SNP_geno1)) {
            # ih = 1; ih = 2
            geno1 = re[[ih]]  # SNP calls from data
            geno2 = re1[[ih]]  # SNP calls from microhaplotype
            
            jud1 = "NULL"
            if ("R" %in% geno2) {
              if (length(geno2) == 2) {
                geno2 = geno2[-which(geno2 %in% "R")]  # Remove R if there's another allele
              } else {
                # Only R, use SNP calls from data
                geno2 = geno1
                vc1 = unlist(str_split(SNP_geno1[ih], pattern = ";"))[1]  # Position
                jud1 = paste("Uncover", vc1, "-", paste(geno2, collapse = ";"), sep = "")
              }
            }
            
            if (identical(geno1, geno2)) {
              if (jud1 == "NULL") {
                Judge = paste(Judge, "T", sep = "|")  # Match
              } else {
                Judge = paste(Judge, jud1, sep = "|")  # Uncovered position
              }
            } else {
              Judge = paste(Judge, "F", sep = "|")  # Mismatch
            }
          }
          
          gre_num = grep(Judge, pattern = "F")
          if (length(gre_num) == 0) {
            break  # Found consistent microhaplotype
          }
        }
        
        Final_re$Judge_SNP[ig] = Judge
        Final_re$MH_result[ig] = MH2$V1[eg]
      } else {
        ## Further judgment needed
        num_row = nrow(MH2)
        if (num_row != 1) {
          # Try pairs of microhaplotypes
          for (ij in 1:(num_row - 1)) {
            # ij = 1
            for (ik in (ij + 1):num_row) {
              # ik = 2
              SNP_MH = gsub(as.character(MH2$V1[c(ij, ik)]), pattern = "[0-9]{1,}:", replacement = "")
              SNP_MH = gsub(SNP_MH, pattern = "[0-9]{1,}-", replacement = "")
              SNP_MH = as.data.frame(str_split_fixed(SNP_MH, pattern = "\\|", n = Inf))
              re1 = lapply(1:ncol(SNP_MH), function(x) {
                # x = 1
                gsub(sort(unique(SNP_MH[, x])), pattern = " ", replacement = "")
              })
              
              Judge = NULL
              for (ih in 1:length(SNP_geno1)) {
                # ih = 1; ih = 10
                geno1 = re[[ih]]
                geno2 = re1[[ih]]
                jud1 = "NULL"
                
                if ("R" %in% geno2) {
                  if (length(geno2) == 2) {
                    geno2 = geno2[-which(geno2 %in% "R")]
                  } else {
                    geno2 = geno1
                    vc1 = unlist(str_split(SNP_geno1[ih], pattern = ";"))[1]
                    jud1 = paste("Uncover", vc1, "-", paste(geno2, collapse = ";"), sep = "")
                  }
                }
                
                if (identical(geno1, geno2)) {
                  if (jud1 == "NULL") {
                    Judge = paste(Judge, "T", sep = "|")
                  } else {
                    Judge = paste(Judge, jud1, sep = "|")
                  }
                } else {
                  Judge = paste(Judge, "F", sep = "|")
                }
              }
              
              gre_num = grep(Judge, pattern = "F")
              if (length(gre_num) == 0) {
                break  # Found consistent pair
              }
            }
            gre_num = grep(Judge, pattern = "F")
            if (length(gre_num) == 0) {
              break
            }
          }
          
          Final_re$MH_result[ig] = paste(as.character(MH2$V1[c(ij, ik)]), collapse = "\n")
          Final_re$Judge_SNP[ig] = Judge
        } else {
          # Single microhaplotype but doesn't match all SNPs
          Final_re$MH_result[ig] = paste(as.character(MH2$V1), collapse = "\n")
          SNP_MH = gsub(as.character(MH2$V1), pattern = "[0-9]{1,}:", replacement = "")
          SNP_MH = gsub(SNP_MH, pattern = "[0-9]{1,}-", replacement = "")
          SNP_MH = as.data.frame(str_split_fixed(SNP_MH, pattern = "\\|", n = Inf))
          
          re1 = lapply(1:ncol(SNP_MH), function(x) {
            # x = 1
            gsub(sort(unique(SNP_MH[, x])), pattern = " ", replacement = "")
          })
          
          Judge = NULL
          for (ih in 1:length(SNP_geno1)) {
            # ih = 1; ih = 2
            geno1 = re[[ih]]
            geno2 = re1[[ih]]
            jud1 = "NULL"
            
            if ("R" %in% geno2) {
              if (length(geno2) == 2) {
                geno2 = geno2[-which(geno2 %in% "R")]
              } else {
                geno2 = geno1
                vc1 = unlist(str_split(SNP_geno1[ih], pattern = ";"))[1]
                jud1 = paste("Uncover", vc1, "-", paste(geno2, collapse = ";"), sep = "")
              }
            }
            
            if (identical(geno1, geno2)) {
              if (jud1 == "NULL") {
                Judge = paste(Judge, "T", sep = "|")
              } else {
                Judge = paste(Judge, jud1, sep = "|")
              }
            } else {
              Judge = paste(Judge, "F", sep = "|")
            }
          }
          Final_re$Judge_SNP[ig] = Judge
        }
      }
    }
    
    # Check if final call matches threshold-filtered results
    if (Final_re$MH_result[ig] == Final_re$Result_MH_threshold[ig]) {
      Final_re$Result_Judge[ig] = "TRUE"
    } else {
      Final_re$Result_Judge[ig] = "FALSE"
    }
    
  })
}

# Generate a unique output file name with timestamp and random number
# Format: Processed_bam_YYYY-MM-DD_RandomNumber_MHCalling.txt
re.name <- paste(wd_result, "Processed_bam_", Sys.Date(), "_", 
                 sample(1000000000000, 1), "_MHCalling.txt", sep = "")

# Select only relevant columns from the final results data frame
# Columns 1-3: Tag, Chr, Reads
# Columns 6-10: Key result columns after filtering and processing
Final_re <- Final_re[, c(1:3, 6:10)]

# Assign descriptive column names for the final output
colnames(Final_re) <- c("Tag",                    # Microhaplotype locus identifier
                        "Chr",                    # Chromosome
                        "Reads",                  # Total number of reads covering the locus
                        "Target_Microhaplotype_Genotype",  # Genotype for target microhaplotype positions
                        "Target_SNP_Genotype",    # SNP-level genotypes with frequencies
                        "Other_SNPs_in_Target_Region",     # Non-target SNPs detected in the region
                        "Haplotypes_in_Target_Region",     # All haplotypes observed in the region
                        "Final_Microhaplotype_Genotype")   # Final called microhaplotype genotype
# Write the final results to a tab-separated text file
write.table(Final_re, re.name, sep = "\t", row.names = FALSE)

#message("\n")
#message("===========================================\n")
#message("ANALYSIS COMPLETED SUCCESSFULLY!\n")
#message("===========================================\n")
#message(sprintf("Results saved in: %s\n", wd_link))
#message(sprintf("Total variants: %d\n", nrow(final_results)))
#message(sprintf("Report file: %s\n", basename(report_file)))
#message("===========================================\n\n")



# Return the path to the generated result file for user access
return(re.name)

}



#' Convert Character to ASCII Values with Quality Score Adjustment
#' 
#' This function converts a character string to its corresponding ASCII values
#' and adjusts them by subtracting 33, which is a common transformation for 
#' quality scores in sequencing data (e.g., Phred quality scores).
#'
#' @param x A character string to be converted to ASCII values.
#' 
#' @return A numeric vector containing the adjusted ASCII values (ASCII-33).
#'
#' @examples
#' # Convert a single character
#' charToAscii("A")
#' 
#' # Convert a quality score string
#' charToAscii("IIII")
#' 
#' # Empty input returns numeric(0)
#' charToAscii("")
#'
#' @export
#' @keywords internal
charToAscii <- function(x) {
  # Validate input
  if (!is.character(x)) {
    stop("Input must be a character string")
  }
  
  if (nchar(x) == 0) {
    return(numeric(0))
  }
  
  # Convert character to raw bytes, then to numeric ASCII values
  ascii_values <- as.numeric(charToRaw(x))
  
  # Adjust ASCII values by subtracting 33 (Phred+33 to Phred score)
  ascii_values <- ascii_values - 33
  
  return(ascii_values)
}




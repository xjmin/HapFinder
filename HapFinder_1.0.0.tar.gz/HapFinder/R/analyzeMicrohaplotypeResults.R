#' Analyze Microhaplotype Genotyping Results
#'
#' This function analyzes microhaplotype genotyping output files to determine
#' zygosity status, calculate allele coverage ratios (ACR), and provide
#' comprehensive summary statistics for each locus.
#'
#' @param file_path Character string. Path to the microhaplotype calling output file.
#'                 The file should be tab-separated with specific columns including
#'                 "Tag", "Final_Microhaplotype_Genotype", and "Target_Microhaplotype_Genotype".
#'
#' @return A data frame with the following columns added to the original data:
#'   \itemize{
#'     \item \code{Zygosity}: Zygosity status - "Homozygous", "Heterozygous", or "Low_depth_or_failed"
#'     \item \code{Haplotype_Depth_1}: Read depth for the first haplotype (if applicable)
#'     \item \code{Haplotype_Depth_2}: Read depth for the second haplotype (if heterozygous)
#'     \item \code{ACR}: Allele Coverage Ratio (larger depth / smaller depth) for heterozygous calls
#'     \item \code{ACR_Category}: Categorization of ACR value for quality assessment
#'   }
#'
#' @section Analysis Criteria:
#' \describe{
#'   \item{Homozygous}{When \code{Final_Microhaplotype_Genotype} contains exactly one haplotype}
#'   \item{Heterozygous}{When \code{Final_Microhaplotype_Genotype} contains exactly two haplotypes}
#'   \item{Low_depth_or_failed}{When \code{Final_Microhaplotype_Genotype} is "Low Reads", "Na", 
#'         or contains no valid genotype}
#' }
#'
#' @section ACR Calculation:
#' For heterozygous calls, the Allele Coverage Ratio (ACR) is calculated as:
#' \deqn{ACR = \frac{\text{Larger haplotype depth}}{\text{Smaller haplotype depth}}}
#' ACR values are categorized as:
#' \itemize{
#'   \item \code{Balanced (1.0-1.5)}: Near-equal coverage
#'   \item \code{Moderate imbalance (1.5-3.0)}: Moderate coverage difference
#'   \item \code{Severe imbalance (>3.0)}: Severe coverage difference
#'   \item \code{NA}: For homozygous or failed calls
#' }
#'
#' @examples
#' \dontrun{
#' # Analyze a microhaplotype calling output file
#' result <- analyzeMicrohaplotypeResults("Test_MHCalling.txt")
#' 
#' # View the summary statistics
#' print(result[, c("Tag", "Zygosity", "Haplotype_Depth_1", "Haplotype_Depth_2", "ACR")])
#' 
#' # Count different zygosity categories
#' table(result$Zygosity)
#' }
#'
#' @importFrom data.table fread
#' @importFrom stringr str_split str_extract_all str_trim
#' @export
analyzeMicrohaplotypeResults <- function(file_path) {
  
  # Input validation
  if (!file.exists(file_path)) {
    stop("File does not exist: ", file_path)
  }
  
  # Read the input file
  message("Reading file: ", basename(file_path))
  data <- data.table::fread(file_path, sep = "\t", header = TRUE, stringsAsFactors = FALSE)
  
  # Check for required columns
  required_cols <- c("Tag", "Final_Microhaplotype_Genotype", "Target_Microhaplotype_Genotype")
  missing_cols <- setdiff(required_cols, colnames(data))
  if (length(missing_cols) > 0) {
    stop("Required columns are missing: ", paste(missing_cols, collapse = ", "))
  }
  
  message(paste0("Processing ", nrow(data), " loci..."))
  
  # Initialize result columns
  data$Zygosity <- NA_character_
  data$Haplotype_Depth_1 <- NA_integer_
  data$Haplotype_Depth_2 <- NA_integer_
  data$ACR <- NA_real_
  data$ACR_Category <- NA_character_
  
  # Process each row
  for (i in seq_len(nrow(data))) {
   # i<-1
    # Extract current values
    final_genotype <- data$Final_Microhaplotype_Genotype[i]
    target_genotype <- data$Target_Microhaplotype_Genotype[i]
    tag <- data$Tag[i]
    
    # 1. Determine zygosity based on Final_Microhaplotype_Genotype
    if (is.na(final_genotype) || final_genotype == "" || 
        final_genotype == "Na" || final_genotype == "Low Reads") {
      
      # Case 1: Low depth or failed sequencing
      data$Zygosity[i] <- "Low_depth_or_failed"
      data$Haplotype_Depth_1[i] <- NA
      data$Haplotype_Depth_2[i] <- NA
      data$ACR[i] <- NA
      data$ACR_Category[i] <- "NA"
      
    } else {
      
      # Split the final genotype by newline to count haplotypes
      haplotypes <- unlist(stringr::str_split(final_genotype, "\n"))
      haplotypes <- stringr::str_trim(haplotypes)
      haplotypes <- haplotypes[haplotypes != ""]
      
      # Count valid haplotypes
      num_haplotypes <- length(haplotypes)
      
      if (num_haplotypes == 0) {
        # No valid haplotype found
        data$Zygosity[i] <- "Low_depth_or_failed"
        data$Haplotype_Depth_1[i] <- NA
        data$Haplotype_Depth_2[i] <- NA
        data$ACR[i] <- NA
        data$ACR_Category[i] <- "NA"
        
      } else if (num_haplotypes == 1) {
        # Case 2: Homozygous (single haplotype)
        data$Zygosity[i] <- "Homozygous"
        
        # Extract depth from Target_Microhaplotype_Genotype
        depth <- extractHaplotypeDepths(target_genotype, haplotypes)
        
        if (length(depth) >= 1) {
          data$Haplotype_Depth_1[i] <- depth[1]
          data$Haplotype_Depth_2[i] <- NA
        }
        data$ACR[i] <- NA
        data$ACR_Category[i] <- "NA"
        
      } else if (num_haplotypes == 2) {
        # Case 3: Heterozygous (two haplotypes)
        data$Zygosity[i] <- "Heterozygous"
        
        # Extract depths for both haplotypes
        depths <- extractHaplotypeDepths(target_genotype, haplotypes)
        
        if (length(depths) >= 2) {
          data$Haplotype_Depth_1[i] <- depths[1]
          data$Haplotype_Depth_2[i] <- depths[2]
          
          # Calculate ACR (Allele Coverage Ratio)
          if (depths[1] > 0 && depths[2] > 0) {
            larger_depth <- max(depths)
            smaller_depth <- min(depths)
            acr_value <- larger_depth / smaller_depth
            
            data$ACR[i] <- round(acr_value, 3)
            
            # Categorize ACR value
            if (acr_value >= 1.0 && acr_value <= 1.5) {
              data$ACR_Category[i] <- "Balanced (1.0-1.5)"
            } else if (acr_value > 1.5 && acr_value <= 3.0) {
              data$ACR_Category[i] <- "Moderate imbalance (1.5-3.0)"
            } else if (acr_value > 3.0) {
              data$ACR_Category[i] <- "Severe imbalance (>3.0)"
            }
          }
        }
        
      } else {
        # Case 4: More than 2 haplotypes (unusual, treat as heterozygous with multiple alleles)
        data$Zygosity[i] <- "Heterozygous_multiple"
        warning(paste("Locus", tag, "has", num_haplotypes, 
                      "haplotypes. This exceeds the expected 1-2 for diploid organisms."))
        
        # Extract depths for the first two haplotypes
        depths <- extractHaplotypeDepths(target_genotype, haplotypes[1:2])
        
        if (length(depths) >= 2) {
          data$Haplotype_Depth_1[i] <- depths[1]
          data$Haplotype_Depth_2[i] <- depths[2]
          
          # Calculate ACR for the first two haplotypes
          if (depths[1] > 0 && depths[2] > 0) {
            larger_depth <- max(depths)
            smaller_depth <- min(depths)
            acr_value <- larger_depth / smaller_depth
            
            data$ACR[i] <- round(acr_value, 3)
            
            # Categorize ACR value
            if (acr_value >= 1.0 && acr_value <= 1.5) {
              data$ACR_Category[i] <- "Balanced (1.0-1.5)"
            } else if (acr_value > 1.5 && acr_value <= 3.0) {
              data$ACR_Category[i] <- "Moderate imbalance (1.5-3.0)"
            } else if (acr_value > 3.0) {
              data$ACR_Category[i] <- "Severe imbalance (>3.0)"
            }
          }
        }
      }
    }
  }
  
  # Generate summary statistics
  generateSummaryReport(data)
  
  message("Analysis completed successfully!")
  message(paste0("Processed loci: ", nrow(data)))
  message(paste0("Homozygous: ", sum(data$Zygosity == "Homozygous", na.rm = TRUE)))
  message(paste0("Heterozygous: ", sum(data$Zygosity == "Heterozygous", na.rm = TRUE)))
  message(paste0("Low depth or failed: ", sum(data$Zygosity == "Low_depth_or_failed", na.rm = TRUE)))
  
  if (sum(data$Zygosity == "Heterozygous", na.rm = TRUE) > 0) {
    heterozygous_data <- data[data$Zygosity == "Heterozygous" & !is.na(data$ACR), ]
    if (nrow(heterozygous_data) > 0) {
      message(paste0("Mean ACR (Heterozygous): ", round(mean(heterozygous_data$ACR, na.rm = TRUE), 3)))
      message(paste0("Median ACR (Heterozygous): ", round(median(heterozygous_data$ACR, na.rm = TRUE), 3)))
    }
  }
  
  return(data)
}

# ----------------------------------------------------------------------------
# Helper function to extract haplotype depths
# ----------------------------------------------------------------------------

#' Extract Haplotype Depths from Target_Microhaplotype_Genotype
#'
#' Internal helper function to extract read depths for specific haplotypes
#' from the Target_Microhaplotype_Genotype column.
#'
#' @param target_genotype Character string. The Target_Microhaplotype_Genotype value
#' @param haplotypes Character vector. The haplotypes to extract depths for
#' @return Numeric vector of depths corresponding to the input haplotypes
#' @noRd
extractHaplotypeDepths <- function(target_genotype, haplotypes) {
  
  if (is.na(target_genotype) || target_genotype == "" || 
      target_genotype == "Na" || target_genotype == "Low Reads") {
    return(NA)
  }
  
  depths <- numeric(length(haplotypes))
  
  # Split target genotype by newline
  target_lines <- unlist(stringr::str_split(target_genotype, "\n"))
  target_lines <- stringr::str_trim(target_lines)
  
  # Process each haplotype
  for (h in seq_along(haplotypes)) {
    haplotype <- haplotypes[h]
    
    # Find the line in target_lines that contains this haplotype
    matching_line <- NULL
    for (line in target_lines) {
      # Check if the line starts with the haplotype (before " ** ")
      if (grepl(paste0("^", haplotype, " \\*\\* "), line) || 
          grepl(paste0("^", haplotype, "\\*\\*"), line)) {
        matching_line <- line
        break
      }
    }
    
    if (!is.null(matching_line)) {
      # Extract the depth value (number after "**")
      depth_match <- stringr::str_extract_all(matching_line, "\\*\\*\\s*(\\d+)")
      if (length(depth_match[[1]]) > 0) {
        depth_value <- as.numeric(gsub("\\*\\*\\s*", "", depth_match[[1]][1]))
        depths[h] <- depth_value
      }
    }
  }
  
  return(depths)
}

# ----------------------------------------------------------------------------
# Helper function to generate summary report
# ----------------------------------------------------------------------------

#' Generate Summary Report of Microhaplotype Analysis
#'
#' Internal helper function to generate a comprehensive summary report
#' of the microhaplotype analysis results.
#'
#' @param data Data frame. The analyzed microhaplotype data
#' @return Invisible NULL. Prints summary to console
#' @noRd
generateSummaryReport <- function(data) {
  
  cat("\n")
  cat("=================================================\n")
  cat("MICROHAPLOTYPE GENOTYPING ANALYSIS SUMMARY\n")
  cat("=================================================\n\n")
  
  # Zygosity distribution
  zygosity_table <- table(data$Zygosity, useNA = "ifany")
  zygosity_df <- data.frame(
    Zygosity = names(zygosity_table),
    Count = as.numeric(zygosity_table),
    Percentage = round(as.numeric(zygosity_table) / nrow(data) * 100, 2)
  )
  
  cat("ZYGOSITY DISTRIBUTION:\n")
  print(zygosity_df, row.names = FALSE)
  cat("\n")
  
  # ACR statistics for heterozygous loci
  heterozygous_data <- data[data$Zygosity == "Heterozygous" & !is.na(data$ACR), ]
  if (nrow(heterozygous_data) > 0) {
    cat("ALLELE COVERAGE RATIO (ACR) STATISTICS (Heterozygous loci):\n")
    cat(paste0("  Total heterozygous loci: ", nrow(heterozygous_data), "\n"))
    cat(paste0("  Mean ACR: ", round(mean(heterozygous_data$ACR, na.rm = TRUE), 3), "\n"))
    cat(paste0("  Median ACR: ", round(median(heterozygous_data$ACR, na.rm = TRUE), 3), "\n"))
    cat(paste0("  Minimum ACR: ", round(min(heterozygous_data$ACR, na.rm = TRUE), 3), "\n"))
    cat(paste0("  Maximum ACR: ", round(max(heterozygous_data$ACR, na.rm = TRUE), 3), "\n"))
    cat(paste0("  Standard deviation: ", round(sd(heterozygous_data$ACR, na.rm = TRUE), 3), "\n"))
    
    # ACR categories
    acr_categories <- table(heterozygous_data$ACR_Category, useNA = "ifany")
    acr_cat_df <- data.frame(
      Category = names(acr_categories),
      Count = as.numeric(acr_categories),
      Percentage = round(as.numeric(acr_categories) / nrow(heterozygous_data) * 100, 2)
    )
    
    cat("\nACR CATEGORIES (Heterozygous loci):\n")
    print(acr_cat_df, row.names = FALSE)
  }
  
  # Read depth statistics
  cat("\nREAD DEPTH SUMMARY:\n")
  
  # Homozygous loci depth
  hom_depth <- data$Haplotype_Depth_1[data$Zygosity == "Homozygous"]
  if (length(hom_depth) > 0 && any(!is.na(hom_depth))) {
    cat("Homozygous loci:\n")
    cat(paste0("  Mean depth: ", round(mean(hom_depth, na.rm = TRUE), 1), "\n"))
    cat(paste0("  Median depth: ", round(median(hom_depth, na.rm = TRUE), 1), "\n"))
    cat(paste0("  Range: ", min(hom_depth, na.rm = TRUE), " - ", 
               max(hom_depth, na.rm = TRUE), "\n"))
  }
  
  # Heterozygous loci depths
  het_depth1 <- data$Haplotype_Depth_1[data$Zygosity == "Heterozygous"]
  het_depth2 <- data$Haplotype_Depth_2[data$Zygosity == "Heterozygous"]
  
  if (length(het_depth1) > 0 && any(!is.na(het_depth1))) {
    cat("\nHeterozygous loci - Haplotype 1:\n")
    cat(paste0("  Mean depth: ", round(mean(het_depth1, na.rm = TRUE), 1), "\n"))
    cat(paste0("  Median depth: ", round(median(het_depth1, na.rm = TRUE), 1), "\n"))
    
    cat("\nHeterozygous loci - Haplotype 2:\n")
    cat(paste0("  Mean depth: ", round(mean(het_depth2, na.rm = TRUE), 1), "\n"))
    cat(paste0("  Median depth: ", round(median(het_depth2, na.rm = TRUE), 1), "\n"))
    
    # Combined heterozygous depth
    combined_het_depth <- c(het_depth1, het_depth2)
    cat("\nHeterozygous loci - Combined (both haplotypes):\n")
    cat(paste0("  Mean depth: ", round(mean(combined_het_depth, na.rm = TRUE), 1), "\n"))
    cat(paste0("  Median depth: ", round(median(combined_het_depth, na.rm = TRUE), 1), "\n"))
  }
  
  cat("\n\n" )
  cat("=================================================\n\n")
  
  invisible(NULL)
}


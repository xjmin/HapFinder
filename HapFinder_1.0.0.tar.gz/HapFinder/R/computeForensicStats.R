#' Compute Forensic Statistics from Allele Frequencies
#'
#' @description 
#' Calculates five key forensic genetic statistics from allele frequencies:
#' Expected Heterozygosity (He), Polymorphism Information Content (PIC), 
#' Effective Number of Alleles (Ae), Discrimination Power (DP), and 
#' Probability of Exclusion (PE).
#'
#' @param alle_freq Numeric vector of allele frequencies. The vector should sum 
#'   to 1 (within floating point tolerance) and all values should be between 
#'   0 and 1 inclusive.
#'
#' @return A character vector of length 5 with the following named elements:
#' \describe{
#'   \item{he}{Expected heterozygosity (He), rounded to 6 decimal places}
#'   \item{pic}{Polymorphism information content (PIC), rounded to 6 decimal places}
#'   \item{ae}{Effective number of alleles (Ae), rounded to 6 decimal places}
#'   \item{dp}{Discrimination power (DP), rounded to 6 decimal places}
#'   \item{pe}{Probability of exclusion (PE), rounded to 6 decimal places}
#' }
#'
#' @details
#' This function implements standard forensic genetics calculations for a
#' single genetic locus. Input validation includes checking for NA values,
#' negative frequencies, frequencies exceeding 1, and normalizing frequencies
#' to sum to 1 if needed (with warning).
#'
#' The function performs the following calculations:
#' \itemize{
#'   \item \strong{Expected Heterozygosity (He)}: Also known as gene diversity,
#'     calculated as \eqn{1 - \sum p_i^2} where \eqn{p_i} is the frequency of 
#'     the i-th allele.
#'   \item \strong{Polymorphism Information Content (PIC)}: Measures the 
#'     informativeness of a marker, calculated as 
#'     \eqn{1 - \sum p_i^2 - (\sum p_i^2)^2 + \sum p_i^4}.
#'   \item \strong{Effective Number of Alleles (Ae)}: Reciprocal of homozygosity,
#'     calculated as \eqn{1 / \sum p_i^2}.
#'   \item \strong{Discrimination Power (DP)}: Probability that two randomly
#'     selected individuals have different genotypes, calculated as 
#'     \eqn{1 - \sum_{i=1}^n \sum_{j=1}^n (p_i p_j)^2 k_{ij}} where 
#'     \eqn{k_{ij} = 1} if \eqn{i = j}, else \eqn{k_{ij} = 4}.
#'   \item \strong{Probability of Exclusion (PE)}: Probability that a random
#'     unrelated individual would be excluded as the parent/contributor,
#'     calculated as \eqn{\sum_i p_i(1-p_i)^2 - 0.5 \cdot \sum_{i \neq j} (p_i p_j)^2 (4 - 3p_i - 3p_j)}.
#' }
#'
#' @section Input Requirements:
#' \itemize{
#'   \item Allele frequencies must be provided as a numeric vector
#'   \item Frequencies should sum to 1 (within \code{1e-10} tolerance)
#'   \item All frequencies must be between 0 and 1 inclusive
#'   \item Missing values (NA) are removed with warning
#' }
#'
#' @section Mathematical Formulas:
#' For a locus with alleles \eqn{i = 1, 2, ..., n} and frequencies \eqn{p_i}:
#' 
#' \deqn{He = 1 - \sum_{i=1}^n p_i^2}
#' \deqn{PIC = 1 - \sum_{i=1}^n p_i^2 - \left(\sum_{i=1}^n p_i^2\right)^2 + \sum_{i=1}^n p_i^4}
#' \deqn{Ae = \frac{1}{\sum_{i=1}^n p_i^2}}
#' \deqn{DP = 1 - \sum_{i=1}^n \sum_{j=1}^n (p_i p_j)^2 \cdot k_{ij}}
#' where \eqn{k_{ij} = 1} if \eqn{i = j}, else \eqn{k_{ij} = 4}
#' \deqn{PE = \sum_i p_i(1-p_i)^2 - 0.5 \cdot \sum_{i \neq j} (p_i p_j)^2 (4 - 3p_i - 3p_j)}
#'
#' @examples
#' # Example 1: Simple biallelic marker
#' computeForensicStats(c(0.7, 0.3))
#' 
#' # Example 2: Tetranucleotide marker with four alleles
#' computeForensicStats(c(0.4, 0.3, 0.2, 0.1))
#' 
#' # Example 3: Highly polymorphic marker
#' computeForensicStats(c(0.25, 0.20, 0.15, 0.15, 0.10, 0.10, 0.05))
#' 
#' # Example 4: Using allele counts to compute frequencies
#' allele_counts <- c(50, 30, 20)  # Observed counts for three alleles
#' frequencies <- allele_counts / sum(allele_counts)
#' computeForensicStats(frequencies)
#'
#' @seealso 
#' \code{\link{computeForensicStatsDetailed}} for a more detailed output format.
#'
#' @export
#' @importFrom stats na.omit
computeForensicStats <- function(alle_freq) {
  
  # Input validation and preprocessing
  if (!is.numeric(alle_freq)) {
    stop("alle_freq must be a numeric vector")
  }
  
  # Remove NA values with warning
  if (any(is.na(alle_freq))) {
    warning("NA values found in alle_freq. Removing them for calculation.")
    alle_freq <- stats::na.omit(alle_freq)
  }
  
  # Check for negative frequencies
  if (any(alle_freq < 0)) {
    stop("Allele frequencies cannot be negative")
  }
  
  # Check for frequencies > 1
  if (any(alle_freq > 1)) {
    stop("Allele frequencies cannot exceed 1")
  }
  
  # Normalize frequencies to sum to 1 (with tolerance for floating-point arithmetic)
  freq_sum <- sum(alle_freq)
  tolerance <- 1e-10
  
  if (abs(freq_sum - 1) > tolerance) {
    warning(sprintf("Allele frequencies sum to %.6f, normalizing to 1", freq_sum))
    alle_freq <- alle_freq / freq_sum
  }
  
  # Ensure we have valid frequencies after normalization
  if (any(is.na(alle_freq)) || any(is.infinite(alle_freq))) {
    stop("Invalid allele frequencies after normalization")
  }
  
  # --------------------------------------------------------------------------
  # Internal function definitions for individual statistics
  # --------------------------------------------------------------------------
  
  #' @describeIn computeForensicStats Polymorphism Information Content
  #' @noRd
  pic <- function(x) {
    # PIC = 1 - sum(p_i^2) - [sum(p_i^2)]^2 + sum(p_i^4)
    sum_sq <- sum(x^2)
    1 - sum_sq - sum_sq^2 + sum(x^4)
  }
  
  #' @describeIn computeForensicStats Effective Number of Alleles
  #' @noRd
  ae <- function(x) {
    # Ae = 1 / sum(p_i^2)
    1 / sum(x^2)
  }
  
  #' @describeIn computeForensicStats Expected Heterozygosity
  #' @noRd
  he <- function(x) {
    # He = 1 - sum(p_i^2)
    1 - sum(x^2)
  }
  
  #' @describeIn computeForensicStats Sum of Squared Frequencies
  #' @noRd
  sque <- function(x) {
    # Used in intermediate calculations
    sum(x^2)
  }
  
  #' @describeIn computeForensicStats Part 1 of PE Calculation
  #' @noRd
  Part1 <- function(x) {
    # ∑ p_i * (1 - p_i)^2
    sum(x * (1 - x)^2)
  }
  
  # --------------------------------------------------------------------------
  # Calculate basic statistics
  # --------------------------------------------------------------------------
  
  # Polymorphism Information Content
  pic1 <- pic(alle_freq)
  
  # Effective Number of Alleles
  ae1 <- ae(alle_freq)
  
  # Expected Heterozygosity
  he1 <- he(alle_freq)
  
  # --------------------------------------------------------------------------
  # Discrimination Power (DP) Calculation
  # --------------------------------------------------------------------------
  
  # DP = 1 - ∑∑ (p_i * p_j)^2 * k_{ij}
  # where k_{ij} = 1 if i = j, else k_{ij} = 4
  sum_a <- 0
  num <- length(alle_freq)
  
  for (i in seq_len(num)) {
    for (d in i:num) {
      if (d == i) {
        # Homozygous combination: (p_i * p_i)^2 = p_i^4
        sum_a <- sum_a + (alle_freq[i] * alle_freq[d])^2
      } else {
        # Heterozygous combination: (2 * p_i * p_d)^2 = 4 * (p_i * p_d)^2
        sum_a <- sum_a + (2 * alle_freq[i] * alle_freq[d])^2
      }
    }
  }
  
  # Final DP: 1 - sum of squared genotype frequencies
  sum_a <- 1 - sum_a
  
  # --------------------------------------------------------------------------
  # Probability of Exclusion (PE) Calculation
  # --------------------------------------------------------------------------
  
  # PE based on formula for unrelated individuals
  sum_b <- 0
  
  for (i in seq_len(num)) {
    for (d in seq_len(num)) {
      if (d != i) {
        # For each pair of different alleles
        alle_freq1 <- alle_freq[i]
        alle_freq2 <- alle_freq[d]
        
        # Contribution from this allele pair
        sum_b <- sum_b + ((alle_freq1 * alle_freq2)^2) * 
          (4 - 3 * alle_freq2 - 3 * alle_freq1)
      }
    }
  }
  
  # Final PE calculation
  sum_b <- Part1(alle_freq) - 0.5 * sum_b
  
  # --------------------------------------------------------------------------
  # Prepare and return results
  # --------------------------------------------------------------------------
  
  # Create named vector of results
  results <- c(
    he = as.character(round(he1, 6)),
    pic = as.character(round(pic1, 6)),
    ae = as.character(round(ae1, 6)),
    dp = as.character(round(sum_a, 6)),
    pe = as.character(round(sum_b, 6))
  )
  
  # Alternative: return as a data frame with description
  # Uncomment if you prefer structured output
  # result_df <- data.frame(
  #   Statistic = c("Expected Heterozygosity (He)", 
  #                 "Polymorphism Information Content (PIC)",
  #                 "Effective Number of Alleles (Ae)",
  #                 "Discrimination Power (DP)",
  #                 "Probability of Exclusion (PE)"),
  #   Value = c(round(he1, 6), round(pic1, 6), round(ae1, 6), 
  #             round(sum_a, 6), round(sum_b, 6)),
  #   stringsAsFactors = FALSE
  # )
  
  # Return results as character vector (maintaining original function behavior)
  return(results)
  
  # To return as data frame instead, use:
  # return(result_df)
}

# ----------------------------------------------------------------------------
# Additional helper functions for forensic analysis
# ----------------------------------------------------------------------------

#' Validate Allele Frequency Input
#'
#' Internal helper function to validate allele frequency input.
#'
#' @param freq_vector Numeric vector of allele frequencies
#' @return Logical indicating if input is valid
#' @noRd
.validateAlleleFrequencies <- function(freq_vector) {
  if (!is.numeric(freq_vector)) return(FALSE)
  if (any(is.na(freq_vector))) return(FALSE)
  if (any(freq_vector < 0)) return(FALSE)
  if (any(freq_vector > 1)) return(FALSE)
  if (abs(sum(freq_vector) - 1) > 1e-10) return(FALSE)
  return(TRUE)
}

#' Compute Detailed Forensic Statistics from Allele Frequencies
#'
#' @description 
#' Calculates comprehensive forensic genetic statistics from allele frequencies,
#' including expected heterozygosity, polymorphism information content, effective
#' number of alleles, discrimination power, probability of exclusion, and
#' additional metrics like observed homozygosity and Shannon's information index.
#' This function provides more detailed output than \code{computeForensicStats}.
#'
#' @param alle_freq Numeric vector of allele frequencies. The vector should sum 
#'   to 1 (within floating point tolerance) and all values should be between 
#'   0 and 1 inclusive.
#'
#' @return A list containing the following elements:
#' \describe{
#'   \item{allele_frequencies}{The input allele frequencies (after normalization)}
#'   \item{number_of_alleles}{Total number of alleles in the locus}
#'   \item{homozygosity}{Observed homozygosity (\eqn{\sum p_i^2})}
#'   \item{heterozygosity}{Expected heterozygosity (He)}
#'   \item{polymorphism_information_content}{Polymorphism information content (PIC)}
#'   \item{effective_number_of_alleles}{Effective number of alleles (Ae)}
#'   \item{discrimination_power}{Discrimination power (DP)}
#'   \item{probability_of_exclusion}{Probability of exclusion (PE)}
#'   \item{shannon_index}{Shannon's information index (diversity measure)}
#'   \item{summary_string}{A text summary of the main statistics}
#'   \item{all_statistics}{Named vector containing He, PIC, Ae, DP, and PE (rounded to 6 decimal places)}
#'   \item{intermediate_calculations}{List containing intermediate values used in calculations}
#' }
#'
#' @details
#' This function performs comprehensive forensic genetic analysis for a single
#' genetic locus. It includes all calculations from \code{computeForensicStats}
#' plus additional diversity metrics. The function validates input, normalizes
#' frequencies if necessary, and provides detailed intermediate calculations.
#'
#' The function computes the following statistics:
#' \itemize{
#'   \item \strong{Observed Homozygosity}: Probability that two randomly selected
#'     alleles are identical, calculated as \eqn{\sum p_i^2}.
#'   \item \strong{Expected Heterozygosity (He)}: Also known as gene diversity,
#'     calculated as \eqn{1 - \sum p_i^2} where \eqn{p_i} is the frequency of 
#'     the i-th allele.
#'   \item \strong{Polymorphism Information Content (PIC)}: Measures the 
#'     informativeness of a marker, calculated as 
#'     \eqn{1 - \sum p_i^2 - (\sum p_i^2)^2 + \sum p_i^4}.
#'   \item \strong{Effective Number of Alleles (Ae)}: Reciprocal of homozygosity,
#'     calculated as \eqn{1 / \sum p_i^2}. Represents the number of equally
#'     frequent alleles that would give the same homozygosity.
#'   \item \strong{Discrimination Power (DP)}: Probability that two randomly
#'     selected individuals have different genotypes, calculated as 
#'     \eqn{1 - \sum_{i=1}^n \sum_{j=1}^n (p_i p_j)^2 k_{ij}} where 
#'     \eqn{k_{ij} = 1} if \eqn{i = j}, else \eqn{k_{ij} = 4}.
#'   \item \strong{Probability of Exclusion (PE)}: Probability that a random
#'     unrelated individual would be excluded as the parent/contributor,
#'     calculated as \eqn{\sum_i p_i(1-p_i)^2 - 0.5 \cdot \sum_{i \neq j} (p_i p_j)^2 (4 - 3p_i - 3p_j)}.
#'   \item \strong{Shannon's Information Index}: A diversity measure from
#'     information theory, calculated as \eqn{-\sum p_i \log(p_i)}.
#' }
#'
#' @section Input Requirements:
#' \itemize{
#'   \item Allele frequencies must be provided as a numeric vector
#'   \item Frequencies should sum to 1 (within \code{1e-10} tolerance)
#'   \item All frequencies must be between 0 and 1 inclusive
#'   \item Missing values (NA) are removed with warning
#' }
#'
#' @section Calculation Details:
#' The function performs the following steps:
#' \enumerate{
#'   \item Input validation and frequency normalization
#'   \item Calculation of basic summary statistics (number of alleles, homozygosity)
#'   \item Computation of five core forensic statistics (He, PIC, Ae, DP, PE)
#'   \item Calculation of additional diversity metrics (Shannon's index)
#'   \item Compilation of results in structured format
#' }
#'
#' All calculations use double precision floating-point arithmetic. Results are
#' rounded to 6 decimal places for display, but full precision is maintained
#' in intermediate calculations.
#'
#' @section Mathematical Formulas:
#' For a locus with alleles \eqn{i = 1, 2, ..., n} and frequencies \eqn{p_i}:
#' 
#' \deqn{\text{Homozygosity} = \sum_{i=1}^n p_i^2}
#' \deqn{He = 1 - \sum_{i=1}^n p_i^2}
#' \deqn{PIC = 1 - \sum_{i=1}^n p_i^2 - \left(\sum_{i=1}^n p_i^2\right)^2 + \sum_{i=1}^n p_i^4}
#' \deqn{Ae = \frac{1}{\sum_{i=1}^n p_i^2}}
#' \deqn{DP = 1 - \sum_{i=1}^n \sum_{j=1}^n (p_i p_j)^2 \cdot k_{ij}}
#' where \eqn{k_{ij} = 1} if \eqn{i = j}, else \eqn{k_{ij} = 4}
#' \deqn{PE = \sum_i p_i(1-p_i)^2 - 0.5 \cdot \sum_{i \neq j} (p_i p_j)^2 (4 - 3p_i - 3p_j)}
#' \deqn{\text{Shannon's Index} = -\sum_{i=1}^n p_i \log(p_i)}
#'
#' @examples
#' # Example 1: Simple biallelic marker
#' computeForensicStatsDetailed(c(0.7, 0.3))
#' 
#' # Example 2: Tetranucleotide marker with four alleles
#' computeForensicStatsDetailed(c(0.4, 0.3, 0.2, 0.1))
#' 
#' # Example 3: Highly polymorphic marker
#' computeForensicStatsDetailed(c(0.25, 0.20, 0.15, 0.15, 0.10, 0.10, 0.05))
#' 
#' # Example 4: Using allele counts to compute frequencies
#' allele_counts <- c(50, 30, 20)  # Observed counts for three alleles
#' frequencies <- allele_counts / sum(allele_counts)
#' computeForensicStatsDetailed(frequencies)
#' 
#' # Example 5: Accessing specific results
#' results <- computeForensicStatsDetailed(c(0.6, 0.3, 0.1))
#' results$heterozygosity  # Expected heterozygosity
#' results$discrimination_power  # Discrimination power
#' results$summary_string  # Text summary
#'
#' @seealso 
#' \code{\link{computeForensicStats}} for a simpler output format,
#' \code{\link{.validateAlleleFrequencies}} for input validation.
#'
#' @export
#' @importFrom stats na.omit
computeForensicStatsDetailed <- function(alle_freq) {
  
  # Use the main function for basic calculations
  basic_stats <- computeForensicStats(alle_freq)
  
  # Calculate additional statistics
  freq_vector <- as.numeric(alle_freq)
  
  # Observed homozygosity
  homozygosity <- sum(freq_vector^2)
  
  # Shannon's information index
  shannon_index <- -sum(freq_vector * log(freq_vector))
  
  # Fixation index (F-statistics, simplified)
  # Note: This assumes Hardy-Weinberg equilibrium
  expected_het <- 1 - homozygosity
  fixation_index <- if (expected_het > 0) {
    1 - (expected_het / expected_het)  # Simplified, would need observed heterozygosity
  } else {
    0
  }
  
  # Return detailed results as a list
  list(
    allele_frequencies = freq_vector,
    number_of_alleles = length(freq_vector),
    homozygosity = round(homozygosity, 6),
    heterozygosity = as.numeric(basic_stats["he"]),
    polymorphism_information_content = as.numeric(basic_stats["pic"]),
    effective_number_of_alleles = as.numeric(basic_stats["ae"]),
    discrimination_power = as.numeric(basic_stats["dp"]),
    probability_of_exclusion = as.numeric(basic_stats["pe"]),
    shannon_index = round(shannon_index, 6),
    fixation_index = round(fixation_index, 6),
    summary_string = paste(
      "He =", basic_stats["he"],
      "PIC =", basic_stats["pic"],
      "Ae =", basic_stats["ae"],
      "DP =", basic_stats["dp"],
      "PE =", basic_stats["pe"]
    )
  )
}


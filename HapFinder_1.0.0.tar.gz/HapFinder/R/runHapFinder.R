#' Launch the HapFinder Shiny Application
#'
#' This function launches the interactive Shiny application for
#' microhaplotype analysis. The application provides a user-friendly
#' interface for data upload, parameter setting, analysis execution,
#' and result visualization.
#'
#' @param launch.browser Logical. If TRUE, launch in browser. Default is TRUE.
#' @param port Integer. Port number to launch the app. Default is 3838.
#' @param host Character. Host address. Default is "127.0.0.1".
#'
#' @return This function does not return a value; it launches a Shiny app.
#'
#' @examples
#' \dontrun{
#' # Launch the app in default browser
#' HapFinder::runHapFinder()
#'
#' # Launch on specific port
#' HapFinder::runHapFinder(port = 4242)
#'
#' # Launch without opening browser
#' HapFinder::runHapFinder(launch.browser = FALSE)
#' }
#'
#' @export
runHapFinder <- function(launch.browser = TRUE, port = 3838, host = "127.0.0.1") {
  
  # Get the directory where the app.R file is located
  appDir <- system.file("app", package = "HapFinder")
  
  if (appDir == "") {
    stop("Could not find the Shiny application directory. ",
         "Try re-installing the HapFinder package.", call. = FALSE)
  }
  
  # Launch the Shiny app
  shiny::runApp(
    appDir = appDir,
    launch.browser = launch.browser,
    port = port,
    host = host
  )
}